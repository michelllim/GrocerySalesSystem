
     package data;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;


public class DataStorage {

	//for user
	private Vector<User> storage = new Vector<User>(); // Store User
														// info-username and
														// password

	public void storeUser(User u) {
		this.storage.add(u);
		for (int i = 0; i < storage.size(); i++) {
			User temp = storage.get(i);
		}
	}

	public User[] getAllUsers() {  //for JTable, havent do/use code
		User[] opArr = new User[this.storage.size()];
		this.storage.toArray(opArr);
		return opArr;
	}

	public User getUser(String n) {
		for (int i = 0; i < storage.size(); i++) {
			User temp = storage.get(i);
			if (temp.getUsername().equals(n)) {
				return temp;
			}
		}
		return null;
	}

	public String getRole(String username) {
		for (int i = 0; i < storage.size(); i++) {
			User temp = storage.get(i);
			if (temp.getUsername().equals(username)) {
				return temp.getRole();
			}

		}
		return null;
	}
	
	//for items
	
	private Vector<Item> storageItem = new Vector<Item>(); // store item

	public Item[] getAllItems() {
		Item[] opArrItem = new Item[this.storageItem.size()];
		this.storageItem.toArray(opArrItem);
		return opArrItem;
	}

	public String[] getAllItemNames() { //bonus: Discount
		ArrayList<String> tempList = new ArrayList<String>();
		for (int i = 0; i< storageItem.size(); i++){
			Item temp = storageItem.get(i);
			tempList.add(temp.getItemName());
		}
		String[] opArrItemNames = new String[tempList.size()];
		tempList.toArray(opArrItemNames);
		return opArrItemNames;
	}
	
	public void storeItem(Item gi) {
		this.storageItem.add(gi);

		System.out.println("Name: " + gi.getItemName());
		System.out.println("Description: " + gi.getItemDescription());
		System.out.println("Brand: " + gi.getItemBrand());
		System.out.println("Price: " + gi.getItemPrice());
		System.out.println("Stock: " + gi.getItemStock());
		System.out.println("Category: " + gi.getItemCategory());
		System.out.println("Expiry Date: " + gi.getExpireDate());
		
	}

	public void deleteItem(int numRows, Item s) {
		this.storageItem.remove(numRows);
		this.storageItem.remove(s);

	}

	public void editItem(int index, Item editedItem, String fileS) {
		this.storageItem.setElementAt(editedItem, index);
		storageItem.get(index).setImage(fileS);
	}
	
	public void clearAllItems() { //clear item storage
		storageItem.removeAllElements();
	}

	public Object getStorageItemSize() {
		return storageItem.size();
	}
	
	public void setDefaultItem() {
		String path = "src/data/DefaultItemCSV.csv";
		String read = "";

		try {

			BufferedReader od = new BufferedReader(new FileReader(path));
			ArrayList<String> lines = new ArrayList<>();
			while ((read = od.readLine()) != null) {

				lines.add(read);
			}
			od.close();
			for (int a = 1; a < lines.size(); a++) {
				String[] value = lines.get(a).split(",");
				Item i = new Item();

				i.setItemName(value[0]);
				i.setItemDescription(value[1]);
				i.setItemBrand(value[2]);
				i.setItemPrice(new Double(value[3])); //original price
				i.setItemStock(new Integer(value[4]));
				i.setItemStockRemaining(new Integer(value[5]));
				i.setItemStockSold(new Integer(value[6]));
				i.setItemCategory(value[7]);
				i.setItemDiscountpercent(new Float(value[8]));
				i.setItemDiscount(new Double(value[9]));
				i.setItemDiscountedPrice(new Double(value[10]));
			    i.setExpireDate(value[11]);
			    i.setImage(value[12]);
			    i.setDstartDate(value[13]);
			    i.setDstartDate(value[14]);
				storageItem.add(i);
				System.out.println("storageItem size is "+ storageItem.size());
			}
			for (int e = 0; e<storageItem.size();e++ ){
				System.out.println("category of first index is" + storageItem.get(e).getExpireDate());
			}

		} catch (IOException e) {
			System.out.println("There was a problem:" + e);
		}
	}

	public void writeCSVItems(){
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter("src/data/DefaultItemCSV.csv"));
			String title = 
			"name,description,brand,original price,stock,stock remaining,stock sold,catergory,disount(%),discount,discounted price,expiry date,file name,Discount start date,Discount end date";
			

			bw.write(title);
			
			for(int i=0; i<storageItem.size();i++){
				Item temp = storageItem.get(i);
				String price = Double.toString(temp.getItemPrice());
				String discount = Double.toString(temp.getItemDiscount());//7,
				String discountprice = Double.toString(temp.getItemDiscountedPrice());
				String line = String.format("%s,%s,%s,%s,%d,%d,%d,%s,%f,%s,%s,%s,%s,%s,%s", 
						temp.getItemName(),temp.getItemDescription(),temp.getItemBrand(),price,temp.getItemStock(),temp.getItemStockRemaining(),temp.getItemStockSold(),
						temp.getItemCategory(),temp.getItemDiscountpercent(),discount,discountprice,temp.getExpireDate(),temp.getImage(),temp.getDstartDate(),temp.getDendDate());

				bw.newLine();	
				bw.write(line);
			}
			
			System.out.println("csv writer");
			bw.close();
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	//for orders
	
	private static Vector<Vector<OrderItem>> orderList = new Vector<>();
	private Vector<OrderDetail> orderDList = new Vector<>();

	public void setDefaultOrders() {

		String path = "src/data/DefaultOrdersCSV.csv";
		String read = ""; 

		try {
			BufferedReader od = new BufferedReader(new FileReader(path));
			ArrayList<String> lines = new ArrayList<>();
			ArrayList<Integer> indexD = new ArrayList<>();
			ArrayList<Integer> indexI = new ArrayList<>();
			while ((read = od.readLine()) != null) {
				lines.add(read);
			}
			//System.out.println(lines.toString());
			for(int i=0; i<lines.size();i++){
				String[] check = lines.get(i).split(",");
				System.out.println(lines.get(i));
				if (check[0].equals("Order Details")){
					indexD.add(i);
					OrderDetail DefaultO = new OrderDetail();
					String[] value = lines.get(i+1).split(",");
					System.out.println("detail i is "+ i);
					
					
					//System.out.println("value is "+ value[0]);
					DefaultO.setOrderNo(Integer.valueOf(value[0]));
					DefaultO.setDate(value[1]);
					DefaultO.setTime(value[2]);
					DefaultO.setTotalOrderPrice(Double.valueOf(value[3]));
					DefaultO.setSubTotalPrice(Double.valueOf(value[4]));
					DefaultO.setGst(Double.valueOf(value[5]));
					DefaultO.setTotalSavings(Double.valueOf(value[6]));
					DefaultO.setTotalQuantity(Integer.valueOf(value[7]));
					DefaultO.setTotalItems(Integer.valueOf(value[8]));
					DefaultO.setStaffName(value[9]);
					orderDList.add(DefaultO);
				}

				if (check[0].equals("Order Items")){
					System.out.println("order items i is "+ i);
					indexI.add(i);
				}	
			}
			System.out.println("number of index Detail "+ indexD);
			System.out.println("number of index Item "+ indexI);
			indexD.remove(0);
			indexD.add(lines.size());
			
			for(int q=0;q<(indexI.size());q++){
				Vector<OrderItem> temp = new Vector<>();
				System.out.println("indeI "+ (indexI.get(q)+1));
				System.out.println("indexD "+ indexD.get(q));
				for(int c=(indexI.get(q)+1);c<indexD.get(q);c++){
					String[] value = lines.get(c).split(",");
					OrderItem o = new OrderItem();
					o.setName(value[0]);
					o.setQuantity(Integer.valueOf(value[1]));
					o.setPrice(Double.valueOf(value[2]));
					o.setDiscount(Double.valueOf(value[3]));
					//System.out.println("value C "+value[0]);
					temp.add(o);
				}
				orderList.add(temp);
				System.out.println("                             end loop");
			}

			od.close();


		} catch (IOException e) {
			System.out.println("There was a problem:" + e);
		}
	}
	
	public void writecsvOrders() {
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter("src/data/DefaultOrdersCSV.csv"));
			for(int i=0; i<orderList.size();i++){
				Vector<OrderItem> temp = orderList.get(i);
				OrderDetail temp1 = orderDList.get(i);
				bw.write("Order Details");
				bw.newLine();
				
					DecimalFormat decfor = new DecimalFormat("0.00");
					String tp = decfor.format(temp1.getTotalOrderPrice());
					String sp = decfor.format(temp1.getSubTotalPrice());
					String gst = decfor.format(temp1.getGst());
					String ts = decfor.format(temp1.getTotalSavings());
					String line = String.format("%d,%s,%s,%s,%s,%s,%s,%d,%d,%s", 
							i+1,temp1.getDate(),temp1.getTime(),tp,sp,gst,ts,temp1.getTotalQuantity(),temp1.getTotalItems(),temp1.getStaffName());
					bw.write(line);
					bw.newLine();
					
					bw.write("Order Items");
					bw.newLine();
					for(int q=0; q<temp.size();q++){
						OrderItem temp3 = temp.get(q);
						String price = decfor.format(temp3.getPrice());
						String dis = decfor.format(temp3.getDiscount());
						String line1 = String.format("%s,%d,%s,%s",temp3.getName(),temp3.getQuantity(),price, dis);
						bw.write(line1);
						bw.newLine();	
					}
					
			}
			bw.close();
			System.out.println(orderList.size());
			System.out.println("in orders write");
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void createOrder() {
		Vector<OrderItem> order = new Vector<>(); // store order Item info - name,quantity, price, discount
		OrderDetail orderD = new OrderDetail();  //store order details
		orderList.add(order);
		orderDList.add(orderD);
	}
	


	public int getOrderListSize() {  //use this to get the orderNumber 
		return orderList.size();
	}

	public String[] getSelectionsFPItems() {
		ArrayList<String> tempList = new ArrayList<String>();
		for (int i = 0; i< storageItem.size(); i++){
			Item temp = storageItem.get(i);
			if (temp.getItemCategory().equals("Fresh Produce")){
				if(temp.getItemStockRemaining()>0){
					tempList.add(temp.getItemName());
				}
			}
		}
		String[] opArrFPItems = new String[tempList.size()];
		tempList.toArray(opArrFPItems);
		return opArrFPItems;
	}

	public String[] getSelectionsFCItems() {
		ArrayList<String> tempList = new ArrayList<String>();
		for (int i = 0; i< storageItem.size(); i++){
			Item temp = storageItem.get(i);
			if (temp.getItemCategory().equals("Food Cupboard")){
				if(temp.getItemStockRemaining()>0){
				tempList.add(temp.getItemName());
				}
			}
		}
		String[] opArrFCItems = new String[tempList.size()];
		tempList.toArray(opArrFCItems);
		return opArrFCItems;
	}

	public String[] getSelectionsSNItems() {
		ArrayList<String> tempList = new ArrayList<String>();
		for (int i = 0; i< storageItem.size(); i++){
			Item temp = storageItem.get(i);
			if (temp.getItemCategory().equals("Snacks")){
				if(temp.getItemStockRemaining()>0){
				tempList.add(temp.getItemName());
				}
			}
		}
		String[] opArrSNItems = new String[tempList.size()];
		tempList.toArray(opArrSNItems);
		return opArrSNItems;
	}

	public String[] getSelectionsDRItems() {
		ArrayList<String> tempList = new ArrayList<String>();
		for (int i = 0; i< storageItem.size(); i++){
			Item temp = storageItem.get(i);
			if (temp.getItemCategory().equals("Drinks")){
				if(temp.getItemStockRemaining()>0){
				tempList.add(temp.getItemName());
				}
			}
		}
		String[] opArrDRItems = new String[tempList.size()];
		tempList.toArray(opArrDRItems);
		return opArrDRItems;
	}

	public String[] getSelectionsFrozenPItems() {
		ArrayList<String> tempList = new ArrayList<String>();
		for (int i = 0; i< storageItem.size(); i++){
			Item temp = storageItem.get(i);
			if (temp.getItemCategory().equals("Frozen Products")){
				if(temp.getItemStockRemaining()>0){
				tempList.add(temp.getItemName());
				}
			}
		}
		String[] opArrFrozenPItems = new String[tempList.size()];
		tempList.toArray(opArrFrozenPItems);
		return opArrFrozenPItems;
	}

	public String[] getSelectionsOTItems() {
		ArrayList<String> tempList = new ArrayList<String>();
		for (int i = 0; i< storageItem.size(); i++){
			Item temp = storageItem.get(i);
			if (temp.getItemCategory().equals("Others")){
				if(temp.getItemStockRemaining()>0){
				tempList.add(temp.getItemName());
				}
			}
		}
		String[] opArrOTItems = new String[tempList.size()];
		tempList.toArray(opArrOTItems);
		return opArrOTItems;
	}

	public String[] getSelectionsDisItems() {
		ArrayList<String> tempList = new ArrayList<String>();
		for (int i = 0; i< storageItem.size(); i++){
			Item temp = storageItem.get(i);
			if (temp.getItemDiscount()>0){
				if(temp.getItemStockRemaining()>0){
				tempList.add(temp.getItemName());
				}
			}
		}
		String[] opArrDisItems = new String[tempList.size()];
		tempList.toArray(opArrDisItems);
		return opArrDisItems;
	}
	
	public Item getItem(String name) {
		for (int i=0; i < storageItem.size();i++){
			Item temp = storageItem.get(i);
			if (temp.getItemName().equals(name)){
				return temp;
			}
		}
		return null;
		
	}

	public void storeOrderItem(int index, OrderItem o) {
		orderList.get(index-1).add(o);
		System.out.println("order size after adding is "+orderList.get(index-1).size());   //testing for correct size after adding 
		
	}

	public int getItemStockRemain(String name) {
		for(int i=0;i<storageItem.size();i++){
			Item temp = storageItem.get(i);
			if(temp.getItemName().equals(name)){
				return temp.getItemStockRemaining();
			}
		}
		return 0;
	}

	public OrderItem[] getAllOrderItems(int index) {
		OrderItem[] opArr = new OrderItem[this.orderList.get(index-1).size()];
		this.orderList.get(index-1).toArray(opArr);
		System.out.println("oparr size in getallorderitem is " + opArr.length);
		return opArr;
	}
	

	public void editOrderItem(int index, int indexT, OrderItem oItem) {
		orderList.get(index-1).set(indexT, oItem);
		
	}

	public void deleteOrderItem(int index, int i) {
		orderList.get(index-1).remove(i);
		
	}

	public void deleteOrder(int index) {
		orderList.remove(index);   //remove order
		orderDList.remove(index);  //remove orderDetail
		System.out.println("orderlist size after delete order is "+ orderList.size());
		
	}


	public int getOrderSize(int index) {
		orderDList.get(index-1).setTotalItems(orderList.get(index-1).size());
		return orderList.get(index-1).size();
	}

	public String getTotalPrice(int index) {    //sum the price and add in orderDList
		DecimalFormat decfor = new DecimalFormat("0.00");
		double totalPrice = 0;
		for (int i = 0; i < orderList.get(index -1).size(); i++){
			double price = orderList.get(index -1).get(i).getPrice() * orderList.get(index-1).get(i).getQuantity();
			totalPrice = totalPrice + price;
		}
		orderDList.get(index-1).setTotalOrderPrice(Double.valueOf(decfor.format(totalPrice))); 
		System.out.println("orderDlist totalprice is " + orderDList.get(index-1).getTotalOrderPrice());
		orderDList.get(index-1).setGst(Double.valueOf(decfor.format((totalPrice/108)*8))); //set gst
		orderDList.get(index-1).setSubTotalPrice(Double.valueOf(decfor.format((totalPrice/108)*100))); //set subprice
		return decfor.format(totalPrice);
	}

	public int getOrderTotalQuantity(int index) {    //sum the quantity and add in orderDList
		int totalQuantity = 0;
		for(int i = 0; i< orderList.get(index -1).size();i++){
			int quantity = orderList.get(index - 1).get(i).getQuantity();
			totalQuantity = totalQuantity + quantity;
		}
		orderDList.get(index - 1).setTotalQuantity(totalQuantity);
		return totalQuantity;
	}

	public String getOrderTotalDis(int index) {    //sum the discount and add in orderDList
		DecimalFormat decfor = new DecimalFormat("0.00");
		double totalDis = 0;
		for(int i=0; i<orderList.get(index -1).size(); i++){
			double Dis =orderList.get(index -1).get(i).getDiscount() * orderList.get(index-1).get(i).getQuantity();
			totalDis = totalDis + Dis;
		}
		orderDList.get(index-1).setTotalSavings(Double.valueOf(decfor.format(totalDis)));
		System.out.println("orderDlist totaldisprice is " + orderDList.get(index-1).getTotalSavings());

		return decfor.format(totalDis);
	}

	public void clearOrderItem(int index) {
		orderList.get(index-1).removeAllElements();
		System.out.println("orderlist after clear is " + orderList.get(index-1).size());
		
	}

	public void saveDateTime(int index, String date, String time) {
		orderDList.get(index-1).setDate(date);
		orderDList.get(index-1).setTime(time);
	}

	public OrderDetail getOrderDetail(int index) {
		return orderDList.get(index-1);   
	}

	public String staffNameOrder(String n) {
		for (int i = 0; i < storage.size(); i++) {
			User temp = storage.get(i);
			if (temp.getUsername().equals(n)) {
				return temp.getStaffName();
			}
		}
		return null;
	}

	public void setStaffNameNumOrder(int index, String sname) {
		orderDList.get(index-1).setStaffName(sname);
		orderDList.get(index-1).setOrderNo(index);
		for (int i=0; i<orderDList.size();i++){
			System.out.println("staff name is "+ orderDList.get(i).getStaffName());
		}

	}

	public void updateStockRemain(int index) { //search in jtable.
		int stockR =0;
		for(int a=0;a<orderList.get(index-1).size();a++){
			OrderItem orderI = orderList.get(index-1).get(a);
			for(int i=0; i<storageItem.size();i++){
				Item temp = storageItem.get(i);
				if(temp.getItemName().equals(orderI.getName())){
					stockR = temp.getItemStock() - orderI.getQuantity();
					temp.setItemStockRemaining(stockR);
					temp.setItemStockSold(orderI.getQuantity());
				}
			}
		}

	
	}

	public Item[] getAllItemsOfDate(String expdate) {
		Vector<Item> temp = new Vector<Item>();
		int count = 0;
		
		for(int a=0;a<storageItem.size();a++){
			Item item = storageItem.get(a);
			if (item.getExpireDate().equals(expdate)){
				temp.add(item);
				count++;
				System.out.println("count is "+ count);
			}
		}
		Item[] opArrItem = new Item[count];
		temp.toArray(opArrItem);
		return opArrItem;
	}
	
	public OrderDetail[] getAllOrders() {
		OrderDetail[] opArrOrders = new OrderDetail[this.orderDList.size()];
		this.orderDList.toArray(opArrOrders);
		return opArrOrders;
	}

	public OrderDetail[] getAllOrderDetails() {
		OrderDetail[] opArrOrderD = new OrderDetail[this.orderDList.size()];
		this.orderDList.toArray(opArrOrderD);
		return opArrOrderD;
	}

	public String getItemImage(String iname) {
		for(int i=0; i<storageItem.size();i++){
			Item temp = storageItem.get(i);
			if (temp.getItemName().equals(iname)){
				return temp.getImage();
			}
		}
		return null;
	}

	public float getItemDiscount(String iname) {
		for(int i=0; i<storageItem.size();i++){
			Item temp = storageItem.get(i);
			if (temp.getItemName().equals(iname)){
				return temp.getItemDiscountpercent();
			}
		}
		return 0;
	}
	
	
	//sale summary
	public Map<String,List<OrderDetail>> sortOrdersByDates(){ //use hashmap to sort
		Map<String,List<OrderDetail>> perDates=new HashMap<>();
		if(orderDList!=null){
			for(OrderDetail a:orderDList){
				String date=a.getDate();
				perDates.computeIfAbsent(date, k -> new ArrayList<>()).add(a); //if date is same, add orderdetail
			}
			
		}
		else{
			System.out.println("Empty order list.");
		}
		return perDates; 

	}
	
	public Map<String,List<Double>> calcSalesByDates(){
		Map<String,List<Double>> allCalcs=new HashMap<>();
		Map<String,List<OrderDetail>> perDates=sortOrdersByDates();
		for(String date: perDates.keySet()){
			double tSal = 0;
			double tNet = 0;
			double tDis = 0;
			double tTax = 0;
			double tQuan = 0;
			double tOrders = 0;
			List<OrderDetail> separateDates=perDates.get(date);
			for(OrderDetail d:separateDates){
				tOrders++;
				tSal += d.getTotalOrderPrice();
				tNet += d.getSubTotalPrice();
				tDis += d.getTotalSavings();
				tTax += d.getGst();
				tQuan += d.getTotalQuantity();
				
			}
//			System.out.println(date+": Sale: "+tSal);
//			System.out.println(date+": Net: "+tNet);
//			System.out.println(date+": Disc: "+tDis);
//			System.out.println(date+": Tax: "+tTax);
//			System.out.println(date+": Quantity: "+tQuan);
//			System.out.println(date+": OrdersRec: "+tOrders);
			allCalcs.computeIfAbsent(date, k -> new ArrayList<>()).add(tSal);
			allCalcs.computeIfAbsent(date, k -> new ArrayList<>()).add(tNet);
			allCalcs.computeIfAbsent(date, k -> new ArrayList<>()).add(tDis);
			allCalcs.computeIfAbsent(date, k -> new ArrayList<>()).add(tTax);
			allCalcs.computeIfAbsent(date, k -> new ArrayList<>()).add(tQuan);
			allCalcs.computeIfAbsent(date, k -> new ArrayList<>()).add(tOrders);
		}
		//System.out.println(allCalcs.size());
		return allCalcs;
	}
	
	public Map<String,List<OrderDetail>> sortOrdersByMonth(){
		Map<String,List<OrderDetail>> perMonth=new HashMap<>();
		if(orderDList!=null){
			for(OrderDetail a:orderDList){
				String date=a.getDate();
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yy");
				LocalDate localDate = LocalDate.parse(date, formatter);

		        Month month = localDate.getMonth();
		        int year = localDate.getYear();
		        perMonth.computeIfAbsent((month.toString()+"-"+year), k -> new ArrayList<>()).add(a);
		}
		}
		else{
			System.out.println("Empty order list.");
		}
		return perMonth; 

	}
	public Map<String,List<Double>> calcSalesByMonth(){
		Map<String,List<Double>> allCalcs=new HashMap<>();
		Map<String,List<OrderDetail>> perMonth=sortOrdersByMonth();
		for(String month: perMonth.keySet()){
			double tSal = 0;
			double tNet = 0;
			double tDis = 0;
			double tTax = 0;
			double tQuan = 0;
			double tOrders = 0;
			List<OrderDetail> separateDates=perMonth.get(month);
			for(OrderDetail d:separateDates){
				tOrders++;
				tSal += d.getTotalOrderPrice();
				tNet += d.getSubTotalPrice();
				tDis += d.getTotalSavings();
				tTax += d.getGst();
				tQuan += d.getTotalQuantity();
				
			}
//			System.out.println(month+": Sale: "+tSal);
//			System.out.println(month+": Net: "+tNet);
//			System.out.println(month+": Disc: "+tDis);
//			System.out.println(month+": Tax: "+tTax);
//			System.out.println(month+": Quantity: "+tQuan);
//			System.out.println(month+": OrdersRec: "+tOrders);
			allCalcs.computeIfAbsent(month, k -> new ArrayList<>()).add(tSal);
			allCalcs.computeIfAbsent(month, k -> new ArrayList<>()).add(tNet);
			allCalcs.computeIfAbsent(month, k -> new ArrayList<>()).add(tDis);
			allCalcs.computeIfAbsent(month, k -> new ArrayList<>()).add(tTax);
			allCalcs.computeIfAbsent(month, k -> new ArrayList<>()).add(tQuan);
			allCalcs.computeIfAbsent(month, k -> new ArrayList<>()).add(tOrders);
			
		}
		return allCalcs;
	}
	
	public Map<Integer,List<OrderDetail>> sortOrdersByYear(){
		Map<Integer,List<OrderDetail>> perYear=new HashMap<>();
		if(orderDList!=null){
			for(OrderDetail a:orderDList){
				String date=a.getDate();
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yy");
				LocalDate localDate = LocalDate.parse(date, formatter);

		        int year = localDate.getYear();
		        perYear.computeIfAbsent((year), k -> new ArrayList<>()).add(a);
		}
		}
		else{
			System.out.println("Empty order list.");
		}
		return perYear; 

	}
	
	public Map<Integer,List<Double>> calcSalesByYear(){
		Map<Integer,List<Double>> allCalcs=new HashMap<>();
		Map<Integer,List<OrderDetail>> perYear=sortOrdersByYear();
		for(Integer year: perYear.keySet()){
			double tSal = 0;
			double tNet = 0;
			double tDis = 0;
			double tTax = 0;
			double tQuan = 0;
			double tOrders = 0;
			List<OrderDetail> separateDates=perYear.get(year);
			for(OrderDetail d:separateDates){
				tOrders++;
				tSal += d.getTotalOrderPrice();
				tNet += d.getSubTotalPrice();
				tDis += d.getTotalSavings();
				tTax += d.getGst();
				tQuan += d.getTotalQuantity();
				
			}
//			System.out.println(year+": Sale: "+tSal);
//			System.out.println(year+": Net: "+tNet);
//			System.out.println(year+": Disc: "+tDis);
//			System.out.println(year+": Tax: "+tTax);
//			System.out.println(year+": Quantity: "+tQuan);
//			System.out.println(year+": OrdersRec: "+tOrders);
			allCalcs.computeIfAbsent(year, k -> new ArrayList<>()).add(tSal);
			allCalcs.computeIfAbsent(year, k -> new ArrayList<>()).add(tNet);
			allCalcs.computeIfAbsent(year, k -> new ArrayList<>()).add(tDis);
			allCalcs.computeIfAbsent(year, k -> new ArrayList<>()).add(tTax);
			allCalcs.computeIfAbsent(year, k -> new ArrayList<>()).add(tQuan);
			allCalcs.computeIfAbsent(year, k -> new ArrayList<>()).add(tOrders);
			
		}
		return allCalcs;
	}
	
	//sort orders in view orders
	public OrderDetail[] getOrdersByName(String name) {
		int count =0;
		ArrayList<OrderDetail> temp = new ArrayList<>();

		for(int i=0;i<orderDList.size();i++){
			OrderDetail od = orderDList.get(i);
			if (od.getStaffName().equals(name)){
				System.out.println("name is "+ od.getStaffName());
				count++;
				temp.add(od);
				
			}
		}
		OrderDetail[] opArrOrderD = new OrderDetail[count];
		temp.toArray(opArrOrderD);
//		System.out.println("length in ds "+ opArrOrderD.length);
//		System.out.println("temp size "+ temp.size());
		return opArrOrderD;
	}
	public OrderDetail[] getOrdersByDate(String date) {
		int count =0;
		ArrayList<OrderDetail> temp = new ArrayList<>();

		for(int i=0;i<orderDList.size();i++){
			OrderDetail od = orderDList.get(i);
			if (od.getDate().equals(date)){
				System.out.println("name is "+ od.getDate());
				count++;
				temp.add(od);
				
			}
		}
		OrderDetail[] opArrOrderD = new OrderDetail[count];
		temp.toArray(opArrOrderD);
		return opArrOrderD;
	}
}
