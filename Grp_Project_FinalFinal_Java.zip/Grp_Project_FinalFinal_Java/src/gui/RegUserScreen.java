package gui;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;

import controller.MainFrame;
import data.User;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;

import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.border.LineBorder;

public class RegUserScreen extends JPanel {

	private MainFrame main;
	private JTextField username;
	private String aa = "";
	private User[] user;
	private JPasswordField passwordField;
	private JRadioButton rdbtnStaff;
	private JRadioButton rdbtnManager;
	private JTextField staffName;

	public RegUserScreen(MainFrame main) {

		this.main = main;
		setLayout(null);
		this.setSize(1120, 665);

		JLabel lblRegisterUser = new JLabel("");
		lblRegisterUser.setBounds(215, 90, 52, 49);
		Image img2 = new ImageIcon(this.getClass().getResource("/user.png")).getImage().getScaledInstance(lblRegisterUser.getWidth(), lblRegisterUser.getHeight(), Image.SCALE_SMOOTH);
		lblRegisterUser.setIcon(new ImageIcon(img2));	
		add(lblRegisterUser);

		JLabel lblUserName = new JLabel("User Name :");
		lblUserName.setForeground(new Color(138, 43, 226));
		lblUserName.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblUserName.setBounds(56, 231, 127, 43);
		add(lblUserName);
		
		JLabel lblPassword = new JLabel("Password   :");
		lblPassword.setForeground(new Color(138, 43, 226));
		lblPassword.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblPassword.setBounds(56, 349, 154, 53);
		add(lblPassword);

		username = new JTextField();
		username.setText("qwer1234");
		username.setForeground(new Color(138, 43, 226));
		username.setFont(new Font("Dialog", Font.PLAIN, 20));
		username.setBounds(196, 232, 237, 40);
		add(username);
		username.setColumns(10);

		JCheckBox chckbxShowPassword = new JCheckBox("Show password");
		chckbxShowPassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JCheckBox chckbxShowPassword = (JCheckBox) e.getSource();
	               if (chckbxShowPassword.isSelected()) {
	                   passwordField.setEchoChar((char) 0); // Show the password in clear text
	               } else {
	            	   passwordField.setEchoChar('\u25cf'); // Hide the password using the default echo character (bullet)
	               }
			}
		});
		chckbxShowPassword.setForeground(new Color(138, 43, 226));
		chckbxShowPassword.setBackground(Color.WHITE);
		chckbxShowPassword.setBounds(309, 393, 127, 25);
		add(chckbxShowPassword);
		
		JButton regUser = new JButton("Register");
		regUser.setBackground(new Color(147, 112, 219));
		regUser.setForeground(new Color(255, 255, 255));
		regUser.setFont(new Font("Tahoma", Font.PLAIN, 30));
		regUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String un = username.getText();
				String p = passwordField.getText();
				String r = "";
				String sname = staffName.getText();

				boolean same = main.getController().unique(un);
				if (un == ("") || p == ("") || sname == ("")) {
					JOptionPane.showMessageDialog(null, "Please enter username/password/staff's name", "Error message",
							JOptionPane.PLAIN_MESSAGE);

				} else {
					if (same == false)
					{
						if (rdbtnStaff.isSelected()) {
							r = "Staff";
							System.out.println(r);
							main.getController().regUser(un, p, r, sname);
							username.setText("");
							passwordField.setText("");
							staffName.setText("");
							main.showLogin();
						} else if (rdbtnManager.isSelected()) {  
							r = "Manager";
							System.out.println(r);
							main.getController().regUser(un, p, r, sname);
							username.setText("");
							passwordField.setText("");
							staffName.setText("");
							main.showLogin();
						} else {
							System.out.println("put role");
							JOptionPane.showMessageDialog(null, "Please choose a role", "Error message",
									JOptionPane.PLAIN_MESSAGE);
						}
					} else {
						System.out.println("Retry");
						JOptionPane.showMessageDialog(null, "Repeated username/password, enter different username/password", "Error message",
								JOptionPane.PLAIN_MESSAGE);
//						username.setText("");
//						passwordField.setText("");
//						staffName.setText("");
					}

				}
			}
		});
		regUser.setBounds(141, 508, 214, 53);
		add(regUser);

		/*
		 * JButton btnShowAllUser = new JButton("Show All User");
		 * btnShowAllUser.addActionListener(new ActionListener() { public void
		 * actionPerformed(ActionEvent arg0) { user =
		 * main.getController().getAllUsers();
		 * 
		 * for (int i = 0; i < user.length; i++){ User op = user[i]; aa = aa +
		 * op.getName() + "   " + op.getPwd() + " ";
		 * lblUsersShownHere.setText(aa); } } });
		 * 
		 * btnShowAllUser.setBounds(183, 262, 136, 25); add(btnShowAllUser);
		 */
		passwordField = new JPasswordField();
		passwordField.setForeground(new Color(138, 43, 226));
		passwordField.setFont(new Font("Dialog", Font.PLAIN, 20));
		passwordField.setBounds(196, 349, 235, 37);
		add(passwordField);

		JLabel lblRole = new JLabel("Role:");
		lblRole.setForeground(new Color(138, 43, 226));
		lblRole.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblRole.setBounds(55, 287, 100, 42);
		add(lblRole);

		ButtonGroup btnGroup = new ButtonGroup();
		this.rdbtnStaff = new JRadioButton("Staff");
		rdbtnStaff.setForeground(new Color(138, 43, 226));
		rdbtnStaff.setBackground(new Color(255, 255, 255));
		rdbtnStaff.setFont(new Font("Dialog", Font.PLAIN, 20));
		rdbtnStaff.setBounds(196, 281, 91, 59);
		btnGroup.add(rdbtnStaff);
		add(this.rdbtnStaff);
		this.rdbtnManager = new JRadioButton("Manager");
		rdbtnManager.setSelected(true);
		rdbtnManager.setForeground(new Color(138, 43, 226));
		rdbtnManager.setBackground(new Color(255, 255, 255));
		rdbtnManager.setFont(new Font("Dialog", Font.PLAIN, 20));
		rdbtnManager.setBounds(319, 281, 109, 59);
		btnGroup.add(rdbtnManager);
		add(this.rdbtnManager);

		JLabel lblStaffName = new JLabel("Staff Name:");
		lblStaffName.setForeground(new Color(138, 43, 226));
		lblStaffName.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblStaffName.setBounds(56, 164, 237, 42);
		add(lblStaffName);
		
		JLabel lblHaveAnAccount = new JLabel("Have an account?");
		lblHaveAnAccount.setForeground(new Color(138, 43, 226));
		lblHaveAnAccount.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblHaveAnAccount.setBounds(116, 427, 171, 42);
		add(lblHaveAnAccount);
		
		JLabel lblLogin = new JLabel("Login");
		lblLogin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showLogin();
			}
		});
		lblLogin.setForeground(new Color(138, 43, 226));
		lblLogin.setFont(new Font("Dialog", Font.BOLD, 20));
		lblLogin.setBounds(276, 427, 81, 42);
		add(lblLogin);

		staffName = new JTextField();
		staffName.setText("michelle");
		staffName.setForeground(new Color(138, 43, 226));
		staffName.setFont(new Font("Dialog", Font.PLAIN, 20));
		staffName.setBounds(195, 167, 237, 37);
		add(staffName);
		staffName.setColumns(10);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(0, 0, 1120, 665);
		Image img1 = new ImageIcon(this.getClass().getResource("/loginpage2.jpg")).getImage().getScaledInstance(label_1.getWidth(), label_1.getHeight(), Image.SCALE_SMOOTH);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(Color.LIGHT_GRAY));
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(12, 75, 466, 404);
		add(panel);
		label_1.setIcon(new ImageIcon(img1));	
		add(label_1);
		
	}


}