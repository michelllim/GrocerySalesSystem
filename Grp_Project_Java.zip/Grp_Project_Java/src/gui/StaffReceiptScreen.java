package gui;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import controller.MainFrame;
import data.OrderDetail;
import data.OrderItem;
import data.User;

import javax.swing.JScrollPane;
import javax.swing.JTable;

public class StaffReceiptScreen extends JPanel{
	private MainFrame main;
	private JTable table;
	private JLabel lblNumItems;
	private OrderItem[] OrderItem;
	private JList list;
	private JScrollPane scrollPane;
	private Container con ;
	private OrderItem[] oi ;
	private JPanel panel_2;
	private JTable table_1;
	private DefaultTableModel model;
	private OrderItem[] orderItems;
	private User user;
	private int index;

	public StaffReceiptScreen(MainFrame main, int index, User user){
		this.main = main;
		this.user = user;
		this.index = index;
		setLayout(null);
		this.setSize(1120, 665);
		setBackground(new Color(253, 245, 230));
		
		OrderDetail od = main.getController().getOrderDetail(index);
		DecimalFormat decfor = new DecimalFormat("0.00");
		JPanel panel = new JPanel();
		panel.setBackground(new Color(224, 255, 255));
		panel.setBounds(0, 0, 1120, 94);
		add(panel);
		panel.setLayout(null);
		
		JLabel lblGrocerySalesSystem = new JLabel("Joy Minimart");
		lblGrocerySalesSystem.setFont(new Font("Segoe UI Semilight", Font.BOLD, 50));
		lblGrocerySalesSystem.setBounds(386, 13, 355, 67);
		panel.add(lblGrocerySalesSystem);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 215, 0));
		panel_1.setBounds(0, 95, 1120, 50);
		add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
			main.showStaffMenuScreen(user);
			}
		});
		lblNewLabel.setBounds(24, 13, 69, 62);
		Image img = new ImageIcon(this.getClass().getResource("/loginiconn.png")).getImage().getScaledInstance(lblNewLabel.getWidth(), lblNewLabel.getHeight(), Image.SCALE_SMOOTH);
		lblNewLabel.setIcon(new ImageIcon(img));	
		panel.add(lblNewLabel);
		
		JLabel label = new JLabel("");
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showLogin();
			}
		});
		label.setBounds(1019, 13, 69, 62);
		Image img1 = new ImageIcon(this.getClass().getResource("/logout.png")).getImage().getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_SMOOTH);
		label.setIcon(new ImageIcon(img1));
		panel.add(label);
		
		JLabel label_3 = new JLabel("Welcome,");
		label_3.setFont(new Font("Tahoma", Font.PLAIN, 17));
		label_3.setBounds(803, 38, 77, 26);
		panel.add(label_3);
		
		JLabel label_1 = new JLabel(user.getStaffName());
		label_1.setBounds(883, 35, 128, 31);
		panel.add(label_1);
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		JLabel lblItemDetails = new JLabel("Receipt");
		lblItemDetails.setBounds(501, 0, 192, 50);
		panel_1.add(lblItemDetails);
		lblItemDetails.setFont(new Font("Tahoma", Font.BOLD, 25));
		
		JLabel lblStaffName = new JLabel("Staff Name:");
		lblStaffName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblStaffName.setBounds(12, 203, 115, 23);
		add(lblStaffName);
		
		JLabel lblForName = new JLabel(od.getStaffName()); 
		lblForName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblForName.setBounds(152, 203, 169, 23);
		add(lblForName);
		
		JLabel lblDate = new JLabel("Date:");
		lblDate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblDate.setBounds(12, 249, 115, 23);
		add(lblDate);
		
		JLabel lblForDate = new JLabel(od.getDate());
		lblForDate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblForDate.setBounds(152, 249, 158, 22);
		add(lblForDate);
		
		JLabel lblOrderNum = new JLabel("Order Number:");
		lblOrderNum.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblOrderNum.setBounds(12, 158, 139, 23);
		add(lblOrderNum);
		
		JLabel lblForOrderNum = new JLabel(String.valueOf(od.getOrderNo()));
		lblForOrderNum.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblForOrderNum.setBounds(152, 158, 129, 23);
		add(lblForOrderNum);
		
		JLabel labelx = new JLabel("-------------------------------------------------------------------------------------");
		labelx.setBounds(12, 285, 440, 16);
		add(labelx);
		
		 this.panel_2= new JPanel();
		 panel_2.setBackground(new Color(255, 255, 255));
		panel_2.setBounds(450, 158, 658, 464);
		panel_2.setBorder(new LineBorder(new Color(0,0,0),5));
		add(panel_2);
		panel_2.setLayout(null);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(12, 13, 634, 438);
		panel_2.add(scrollPane_1);
		
		table_1 = new JTable();
		scrollPane_1.setViewportView(table_1);
		
		Object[] columns = {
				"Name", "Quantity", "Price per item", "Discount per item"
			};
		this.model = new DefaultTableModel(0,4);
		this.model.setColumnIdentifiers(columns);
		
		JLabel lblTotal = new JLabel("Total $");
		lblTotal.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTotal.setBounds(12, 315, 115, 32);
		add(lblTotal);
		
		JLabel lblForTotalP = new JLabel(decfor.format(od.getTotalOrderPrice()));
		lblForTotalP.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblForTotalP.setBounds(265, 311, 139, 36);
		add(lblForTotalP);
		
		JLabel lblSubTotal = new JLabel("Sub Total $");
		lblSubTotal.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblSubTotal.setBounds(12, 360, 139, 32);
		add(lblSubTotal);
		
		JLabel lblGst = new JLabel("GST (8%)");
		lblGst.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblGst.setBounds(12, 405, 139, 32);
		add(lblGst);
		
		JLabel lblForSubTotal = new JLabel(decfor.format(od.getSubTotalPrice()));
		lblForSubTotal.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblForSubTotal.setBounds(265, 358, 139, 36);
		add(lblForSubTotal);
		
		JLabel lblForGST = new JLabel(decfor.format(od.getGst()));
		lblForGST.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblForGST.setBounds(265, 403, 139, 36);
		add(lblForGST);
		
		lblNumItems = new JLabel("Number of Items:");
		lblNumItems.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNumItems.setBounds(12, 495, 169, 32);
		add(lblNumItems);
		
		JLabel lblForNumItems = new JLabel(String.valueOf(od.getTotalItems()));
		lblForNumItems.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblForNumItems.setBounds(265, 491, 139, 36);
		add(lblForNumItems);
		
		JLabel lblTotalQuantity = new JLabel("Total Quantity:");
		lblTotalQuantity.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTotalQuantity.setBounds(12, 540, 158, 32);
		add(lblTotalQuantity);
		
		JLabel lblTotalQ = new JLabel(String.valueOf(od.getTotalQuantity()));
		lblTotalQ.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTotalQ.setBounds(265, 540, 139, 36);
		add(lblTotalQ);
		
		JLabel lblTotalSavings = new JLabel("Total Savings:");
		lblTotalSavings.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTotalSavings.setBounds(12, 450, 158, 32);
		add(lblTotalSavings);
		
		JLabel lblForTotalS = new JLabel(decfor.format(od.getTotalSavings()));
		lblForTotalS.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblForTotalS.setBounds(265, 452, 139, 36);
		add(lblForTotalS);
		
		JLabel lblForTime = new JLabel(od.getTime());
		lblForTime.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblForTime.setBounds(307, 249, 119, 23);
		add(lblForTime);
		
		JLabel label_2 = new JLabel("Thank you for shopping with us!");
		label_2.setFont(new Font("Tempus Sans ITC", Font.ITALIC, 25));
		label_2.setBounds(46, 585, 392, 36);
		add(label_2);
		
		JButton button = new JButton("Back");
		button.setBackground(new Color(255, 255, 255));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				main.showStaffMenuScreen(user);
			}
		});
		button.setFont(new Font("Tahoma", Font.BOLD, 15));
		button.setBounds(23, 616, 145, 36);
		add(button);
		
		
		addOrderItems(index);
	}
	private void addOrderItems(int i){
		this.model.setRowCount(0);

		this.orderItems = this.main.getController().getAllOrderItems(this.index);
		Object[] row = new Object[4];
		DecimalFormat decfor = new DecimalFormat("0.00");
		for(int e = 0; e < this.orderItems.length; e++){
			OrderItem op = this.orderItems[e];
			row[0] = op.getName();
			row[1] = op.getQuantity();
			row[2] = decfor.format(op.getPrice());
			row[3] = decfor.format(op.getDiscount());
			
			System.out.println("row[0]"+row[0]);
			System.out.println(row[1]);
			System.out.println(row[2]);
			System.out.println(row[3]);
			
			this.model.addRow(row);
			
		}
		table_1.setModel(model);
		
	}
}