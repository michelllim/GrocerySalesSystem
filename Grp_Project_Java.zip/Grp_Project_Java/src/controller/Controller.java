package controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import data.DataStorage;
import data.Item;
import data.OrderDetail;
import data.OrderItem;
import data.User;

public class Controller {

	private static DataStorage ds = new DataStorage();
	//for user
	public void regUser(String n, String p, String r, String sname) { 
		User user = new User();
		user.setUsername(n);
		user.setPassword(p);
		user.setRole(r);
		user.setStaffName(sname);
		this.ds.storeUser(user);
	}
	

	public boolean unique(String n) {

		try {
			String cc = "";

			User t = ds.getUser(n);
			cc = t.getUsername().toString();

			if (n.equals(cc))
				return true;
			else
				return false;
		} catch (NullPointerException e) {
			return false;
		}
	}


	public boolean verifyUser(String n, String pwd) {
		String real = pwd;
		String cc = "";
		User t = ds.getUser(n);
		if (t != null) {
			cc = t.getPassword().toString();
			if (real.equals(cc))
				return true;
			else
				return false;
		} else
			return false;
	}

	public String getRole(String username) {
		return ds.getRole(username);
	}
	public User getUser(String username){
		return ds.getUser(username);
	}
	
	//for items
	public void setDefaultItem() {

		ds.setDefaultItem();
	}
	
	public void clearOrderItem(int index) {
		ds.clearOrderItem(index);
		
	}
	
	public void writecsvItems(){
		ds.writeCSVItems();
	}


	public Item[] getAllItemsOfDate(String expdate) {
		return ds.getAllItemsOfDate(expdate);
	}

	public void addItem(String iname, String idesc, String ibrand, double iprice, int istock, String icat, String exdate, String fileS) {
		Item gi = new Item();
		gi.setItemName(iname);
		gi.setItemDescription(idesc);
		gi.setItemBrand(ibrand);
		gi.setItemPrice(iprice);
		gi.setItemStock(istock);
		gi.setItemStockRemaining(istock);  //added
		gi.setItemCategory(icat);
		gi.setExpireDate(exdate);
		gi.setImage(fileS);
		gi.setItemDiscountpercent(0);
		gi.setDstartDate("Nil");
		gi.setDendDate("Nil");
		
		this.ds.storeItem(gi);
	}

	public void deleteItem(int numRows, Item s) {
		this.ds.deleteItem(numRows, s);

	}

	public void editItem(int index, Item s, String fileS) {
		this.ds.editItem(index, s, fileS);
	}
	
	public void discountItem(String disI, float dis, String sDate, String eDate){ //bonus: Discount
        Item d = ds.getItem(disI);
        d.setItemDiscountpercent(dis/100);
        d.setDstartDate(sDate);
        d.setDendDate(eDate);
        d.setItemDiscountedPrice(d.getItemPrice()*(1-dis/100));
        d.setItemDiscount(d.getItemPrice()-(d.getItemPrice()*(1-dis/100)));
	}

	public void clearAllItems(){ //clear item storage
		ds.clearAllItems();
	}
	
	public Item[] getAllItems() {
		return this.ds.getAllItems();
	}
	
	public String[] getAllItemNames() { //bonus: Discount
		
		return ds.getAllItemNames();
	}
	
	public Object getStorageItemSize() {
		return ds.getStorageItemSize();
	}
	
	public String getItemImage(String iname) {
		return ds.getItemImage(iname);
	}

	public float getItemDiscount(String iname) {
		return ds.getItemDiscount(iname);
	}
	
	//for orders
	public void setDefaultOrders() { //sales summary
		ds.setDefaultOrders();
	}
	public void createOrder(){
		
		ds.createOrder();
	}

	public int getOrderListSize() {
		return  ds.getOrderListSize();
	}


	public String[] getSelectionsFPItems() {
		
		return ds.getSelectionsFPItems();
	}


	public String[] getSelectionsFCItems() {
		return ds.getSelectionsFCItems();
	}


	public String[] getSelectionsSNItems() {
		return ds.getSelectionsSNItems();
	}


	public String[] getSelectionsDRItems() {
		return ds.getSelectionsDRItems();
	}


	public String[] getSelectionsFrozenPItems() {
		return ds.getSelectionsFrozenPItems();
	}


	public String[] getSelectionsOTItems() {
		return ds.getSelectionsOTItems();
	}

	public String[] getSelectionsDisItems() {
		return ds.getSelectionsDisItems();
	}
	

	public void addOrderItem(int index, String name, int quantity) {
		Item  item = ds.getItem(name);
		double price = item.getItemPrice();
		double discount = item.getItemDiscount();
		OrderItem oItem = new OrderItem();
		oItem.setName(name);
		oItem.setQuantity(quantity);
		oItem.setPrice(price);
		
		oItem.setDiscount(discount);
		ds.storeOrderItem(index, oItem);
		System.out.println("orderitem added");   //testing
		System.out.println(quantity);            //testing
		
	}


	public int getItemStockRemain(String name) {
		return ds.getItemStockRemain(name);
	}


	public OrderItem[] getAllOrderItems(int index) {
		return ds.getAllOrderItems(index);
	}


	public void editOrderItem(int index, int indexT, String nameO, int quantityO) {
		Item item = ds.getItem(nameO);
		double price = item.getItemPrice();
		double discount = item.getItemDiscount();
		OrderItem oItem = new OrderItem();
		oItem.setName(nameO);
		oItem.setQuantity(quantityO);
		oItem.setPrice(price);
		oItem.setDiscount(discount);
		ds.editOrderItem(index, indexT, oItem);
		
	}


	public void deleteOrderItem(int index, int i) {
		ds.deleteOrderItem(index, i);
		
	}


	public void deleteOrder(int index) {
		ds.deleteOrder(index);
		
	}


	public int getOrderSize(int index) {
		return ds.getOrderSize(index);
	}


	public String getTotalPrice(int index) {
		
		return ds.getTotalPrice(index);
	}


	public int getOrderTotalQuantity(int index) {
		return ds.getOrderTotalQuantity(index);
	}


	public String getOrderTotalDis(int index) {
		return ds.getOrderTotalDis(index);
	}


	

	public void saveDateTime(int index, String date, String time) {
		ds.saveDateTime(index, date, time);
		
	}


	public OrderDetail getOrderDetail(int index) {
		return ds.getOrderDetail(index);
	}


	public String staffNameOrder(String n) {
		return ds.staffNameOrder(n);
		
	}


	public void setStaffNameNumOrder(int index, String sname) {
		ds.setStaffNameNumOrder(index, sname);
		
	}


	public void updateStockRemain(int index) {
		ds.updateStockRemain(index);
		
	}
	
	
	public OrderDetail[] getAllOrderDetails(){
		return this.ds.getAllOrderDetails();
	}
	
	public OrderDetail[] getAllOrders() {
		return this.ds.getAllOrders();
	}


	public void writecsvOrders() {
		ds.writecsvOrders();
		
	}
	
	//salesummary
	public Map<String,List<OrderDetail>> sortOrdersByDates(){ //sorting in sale sum
		return ds.sortOrdersByDates();
	}
	public Map<String,List<Double>>  calcSalesByDates(){ //calculating sorted orderdetails in sale sum
		return ds.calcSalesByDates();
	}
	public Map<String,List<OrderDetail>> sortOrdersByMonth(){
		return ds.sortOrdersByMonth();
	}
	public Map<String,List<Double>> calcSalesByMonth(){
		return ds.calcSalesByMonth();
	}
	public Map<Integer,List<OrderDetail>> sortOrdersByYear(){
		return ds.sortOrdersByYear();
	}
	public Map<Integer,List<Double>> calcSalesByYear(){
		return ds.calcSalesByYear();
	}
	public OrderDetail[] getOrdersByName(String name) {
		return ds.getOrdersByName(name);
	}
	public OrderDetail[] getOrdersByDate(String date) {  
		return ds.getOrdersByDate(date);
	}
}
