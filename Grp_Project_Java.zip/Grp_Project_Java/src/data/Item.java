package data;

import java.util.Date;

public class Item {
	
	private String itemName;
	private String itemDescription;
	private String itemBrand;
	private double itemPrice; //original price
	private int itemStock;
	private int itemStockRemaining;
	private int itemStockSold;
	private String itemCategory;
	private String image;
	private float itemDiscountpercent; //(%)
	private String dstartDate;
	private String dendDate;
	private String expireDate;
	private String itemCreatedDate;
	
	private double itemDiscountedPrice;
	private double itemDiscount;

	public int getItemStockSold() {
		return itemStockSold;
	}

	public void setItemStockSold(int itemStockSold) {
		this.itemStockSold = itemStockSold;
	}

	public float getItemDiscountpercent() {
		return itemDiscountpercent;
	}

	public void setItemDiscountpercent(float itemDiscountpercent) {
		this.itemDiscountpercent = itemDiscountpercent;
	}

	public double getItemDiscountedPrice() {
		return itemDiscountedPrice;
	}

	public void setItemDiscountedPrice(double itemDiscountedPrice) {
		this.itemDiscountedPrice = itemDiscountedPrice;
	}

	public double getItemDiscount() {
		return itemDiscount;
	}

	public void setItemDiscount(double itemDiscount) {
		this.itemDiscount = itemDiscount;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	
	public String getExpireDate() {
		return expireDate;
	}

	public void setExpireDate(String expireDate) {
		this.expireDate = expireDate;
	}

	public String getItemCreatedDate() {
		return itemCreatedDate;
	}

	public void setItemCreatedDate(String itemCreatedDate) {
		this.itemCreatedDate = itemCreatedDate;
	}

	public int getItemStockRemaining() {
		return itemStockRemaining;
	}

	public void setItemStockRemaining(int itemStockRemaining) {
		this.itemStockRemaining = itemStockRemaining;
	}

	public String getDstartDate() {
		return dstartDate;
	}

	public void setDstartDate(String dstartDate) {
		this.dstartDate = dstartDate;
	}

	public String getDendDate() {
		return dendDate;
	}

	public void setDendDate(String dendDate) {
		this.dendDate = dendDate;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	
	public double getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(double iprice) {
		this.itemPrice = iprice;
	}
	
	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemBrand() {
		return itemBrand;
	}

	public void setItemBrand(String itemBrand) {
		this.itemBrand = itemBrand;
	}

	public int getItemStock() {
		return itemStock;
	}

	public void setItemStock(int itemStock) {
		this.itemStock = itemStock;
	}

	public String getItemCategory() {
		return itemCategory;
	}

	public void setItemCategory(String itemCategory) {
		this.itemCategory = itemCategory;
	}
	
	public Item(){
		this.itemName = "";
		this.itemDescription = "";
		this.itemBrand = "";
		this.itemPrice = 0.0f;
		this.itemStock = 0;
		this.itemStockRemaining = 0;
		this.itemCategory = "Others" ;
		this.itemDiscountpercent = 0.0f;
		this.dstartDate = "Nil";
		this.dendDate = "Nil";
		this.expireDate = "";
	}

	public Item(String name,  String desc, String brand, double price, int stock, String cat, String expDate) {
		this.itemName = name;
		this.itemDescription = desc;
		this.itemBrand = brand;
		this.itemPrice = price;
		this.itemStock = stock;
		this.itemCategory = cat;
		this.expireDate = expDate;

	}
	
	public Item(float dis, String sDate, String eDate) {
		this.itemDiscountpercent = dis;
		this.dstartDate = sDate;
		this.dendDate = eDate;

	}
}

