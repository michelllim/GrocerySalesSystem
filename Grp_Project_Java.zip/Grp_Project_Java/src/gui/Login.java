package gui;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;

import controller.MainFrame;
import data.User;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JCheckBox;
import javax.swing.border.CompoundBorder;
import javax.swing.border.LineBorder;


public class Login extends JPanel{
	
	private JTextField txtA;
	private JLabel lblLoginStatusHere;
	private MainFrame main;
	private JPasswordField passwordField;
	
	public Login(MainFrame main) {
		
		this.main = main;
		setLayout(null);
		this.setSize(1120, 665);
		
		JCheckBox chckbxShowPassword = new JCheckBox("Show password");
		chckbxShowPassword.setForeground(new Color(138, 43, 226));
		chckbxShowPassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JCheckBox chckbxShowPassword = (JCheckBox) arg0.getSource();
	               if (chckbxShowPassword.isSelected()) {
	                   passwordField.setEchoChar((char) 0); // Show the password in clear text
	               } else {
	            	   passwordField.setEchoChar('\u25cf'); // Hide the password using the default echo character (bullet)
	               }
	           }
		});
		
		JLabel lblLoginScreen = new JLabel("");
		lblLoginScreen.setBounds(215, 97, 52, 49);
		Image img2 = new ImageIcon(this.getClass().getResource("/user.png")).getImage().getScaledInstance(lblLoginScreen.getWidth(), lblLoginScreen.getHeight(), Image.SCALE_SMOOTH);
		lblLoginScreen.setIcon(new ImageIcon(img2));	
		add(lblLoginScreen);
		
		chckbxShowPassword.setBackground(Color.WHITE);
		chckbxShowPassword.setBounds(308, 301, 127, 25);
		add(chckbxShowPassword);
		
		JLabel lblUserName = new JLabel("User Name :");
		lblUserName.setForeground(new Color(138, 43, 226));
		lblUserName.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblUserName.setBounds(64, 159, 193, 83);
		add(lblUserName);
		
		JLabel lblPassword = new JLabel("Password   :");
		lblPassword.setForeground(new Color(138, 43, 226));
		lblPassword.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblPassword.setBounds(64, 219, 204, 101);
		add(lblPassword);
		
		txtA = new JTextField();
		txtA.setText("qwer1234");
		txtA.setForeground(new Color(138, 43, 226));
		txtA.setFont(new Font("Dialog", Font.PLAIN, 20));
		txtA.setBounds(200, 182, 235, 37);
		add(txtA);
		txtA.setColumns(10);
		
		JLabel lblLoginStatusHere = new JLabel("Login status");
		lblLoginStatusHere.setForeground(new Color(138, 43, 226));
		lblLoginStatusHere.setFont(new Font("Dialog", Font.PLAIN, 25));
		lblLoginStatusHere.setBounds(168, 384, 158, 37);
		add(lblLoginStatusHere);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setBackground(new Color(147, 112, 219));
		btnLogin.setForeground(new Color(255, 255, 255));
		btnLogin.setIcon(null);
		btnLogin.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnLogin.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				String n = txtA.getText();
				String pwd = passwordField.getText();
				String r = "";
				
				String checkRole = main.getController().getRole(n);
				boolean validity = main.getController().verifyUser(n,pwd);
				
				if (validity == true ){
					lblLoginStatusHere.setText("Successful!");
					
					if (checkRole == "Staff"){
						User user = main.getController().getUser(n);
						main.showStaffMenuScreen(user);
					}
					else {
						User user = main.getController().getUser(n);
						main.showMDashboard(user);
					}
				}
				else
					lblLoginStatusHere.setText("Invalid");
			}
		});
		btnLogin.setBounds(140, 467, 217, 49);
		add(btnLogin);
		
		passwordField = new JPasswordField();
		passwordField.setForeground(new Color(138, 43, 226));
		passwordField.setFont(new Font("Dialog", Font.PLAIN, 20));
		passwordField.setBounds(200, 255, 235, 37);
		add(passwordField);
		
		JLabel lblNewLabel = new JLabel("Don't have an account? ");
		lblNewLabel.setForeground(new Color(138, 43, 226));
		lblNewLabel.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel.setBounds(109, 335, 217, 42);
		add(lblNewLabel);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(0, 0, 1120, 665);
		Image img1 = new ImageIcon(this.getClass().getResource("/loginpage2.jpg")).getImage().getScaledInstance(label_1.getWidth(), label_1.getHeight(), Image.SCALE_SMOOTH);
		
		JLabel lblSignUp = new JLabel("Sign up");
		lblSignUp.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				main.showRegScreen();
			}
		});
		lblSignUp.setForeground(new Color(138, 43, 226));
		lblSignUp.setFont(new Font("Dialog", Font.BOLD, 20));
		lblSignUp.setBounds(318, 335, 109, 42);
		add(lblSignUp);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(Color.LIGHT_GRAY));
		panel.setBackground(Color.WHITE);
		panel.setBounds(23, 81, 451, 351);
		add(panel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(109, 411, 340, 57);
		add(panel_1);
		label_1.setIcon(new ImageIcon(img1));	
		add(label_1);
	}
}