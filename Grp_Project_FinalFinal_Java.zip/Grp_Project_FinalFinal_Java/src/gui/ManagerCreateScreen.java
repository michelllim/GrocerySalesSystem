package gui;

import javax.swing.JPanel;

import controller.MainFrame;
import data.User;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;

import java.awt.Choice;
import javax.swing.JTabbedPane;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;

import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.JToolBar;
import java.awt.Panel;
import com.toedter.calendar.JDateChooser;
import java.awt.event.MouseMotionAdapter;

public class ManagerCreateScreen extends JPanel{
	
	private MainFrame main;
	private User user1;
	private JDateChooser dateChooser;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JComboBox cbCat;
	private String[] valArr = {"Fresh Produce", "Food Cupboard", "Snacks", "Drinks", "Frozen Products", "Others"};
	private JTextField textField_4;
	private JLabel label_1 ;
	private String fileS, fileSC, fileN ;
	private Image img2;
	
	public ManagerCreateScreen(MainFrame main, User user) {
		
		this.main = main;
		this.user1 = user;
		setLayout(null);
		this.setSize(1120, 665);
		
		setBackground(new Color(255, 240, 245));
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(221, 160, 221));
		panel.setBounds(0, 0, 1120, 94);
		add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMDashboard(user1);
			}
		});
		lblNewLabel.setBounds(24, 18, 69, 62);
		Image img = new ImageIcon(this.getClass().getResource("/loginiconn.png")).getImage().getScaledInstance(lblNewLabel.getWidth(), lblNewLabel.getHeight(), Image.SCALE_SMOOTH);
		lblNewLabel.setIcon(new ImageIcon(img));	
		panel.add(lblNewLabel);
		
		JLabel lblGrocerySalesSystem = new JLabel("Joy Minimart");
		lblGrocerySalesSystem.setForeground(new Color(139, 0, 139));
		lblGrocerySalesSystem.setFont(new Font("Segoe UI Semilight", Font.BOLD, 50));
		lblGrocerySalesSystem.setBounds(386, 13, 355, 67);
		panel.add(lblGrocerySalesSystem);
		
		JLabel label = new JLabel("");
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showLogin();
			}
			
		});
		label.setBounds(1054, 29, 54, 42);
		Image img1 = new ImageIcon(this.getClass().getResource("/logout.png")).getImage().getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_SMOOTH);
		label.setIcon(new ImageIcon(img1));
		panel.add(label);
		
		JLabel label_2 = new JLabel(user1.getStaffName());
		label_2.setBounds(922, 29, 104, 42);
		panel.add(label_2);
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		JLabel lblWelcome = new JLabel("Welcome,");
		lblWelcome.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblWelcome.setBounds(833, 38, 77, 26);
		panel.add(lblWelcome);
		
		JPanel panel_1 = new JPanel();
		panel_1.setForeground(new Color(255, 204, 255));
		panel_1.setBackground(new Color(224, 255, 255));
		panel_1.setBounds(0, 121, 1120, 50);
		add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblItemDetails = new JLabel("Create Items");
		lblItemDetails.setForeground(new Color(0, 0, 0));
		lblItemDetails.setBounds(461, 0, 172, 50);
		panel_1.add(lblItemDetails);
		lblItemDetails.setFont(new Font("Tahoma", Font.BOLD, 25));
		
		JLabel lblHome = new JLabel("Home");
		lblHome.setForeground(new Color(0, 0, 0));

		lblHome.setBackground(new Color(240, 255, 255));
		lblHome.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				main.showMDashboard(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblHome.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblHome.setForeground(new Color(0, 0, 0));
			}
		});
		lblHome.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblHome.setBounds(10, 92, 56, 26);
		add(lblHome);
		
		JLabel lblCreateItems = new JLabel("Create Items");
		lblCreateItems.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMCreateScreen(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblCreateItems.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblCreateItems.setForeground(new Color(0, 0, 0));
			}
			
		});
		lblCreateItems.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblCreateItems.setBounds(86, 92, 116, 26);
		add(lblCreateItems);
		
		JLabel lblViewItems = new JLabel("View Items");
		lblViewItems.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMViewItems(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblViewItems.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblViewItems.setForeground(new Color(0, 0, 0));
			}
		});
		lblViewItems.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblViewItems.setBounds(229, 92, 109, 26);
		add(lblViewItems);
		
		JLabel lblViewSaleSummary = new JLabel("View Sale Summary");
		lblViewSaleSummary.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMSaleSummary(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblViewSaleSummary.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblViewSaleSummary.setForeground(new Color(0, 0, 0));
			}
		});
		lblViewSaleSummary.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblViewSaleSummary.setBounds(360, 92, 195, 26);
		add(lblViewSaleSummary);
		
		JLabel lblTrackInventory = new JLabel("Track Inventory");
		lblTrackInventory.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMInventory(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblTrackInventory.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblTrackInventory.setForeground(new Color(0, 0, 0));
			}
		});
		lblTrackInventory.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTrackInventory.setBounds(567, 92, 140, 26);
		add(lblTrackInventory);
		
		JLabel lblViewOrders = new JLabel("View Orders");
		lblViewOrders.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMViewOrders(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblViewOrders.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblViewOrders.setForeground(new Color(0, 0, 0));
			}
		});
		lblViewOrders.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblViewOrders.setBounds(733, 92, 116, 26);
		add(lblViewOrders);
		
		JLabel lblDiscountItems = new JLabel("Discount");
		lblDiscountItems.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMDiscount(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblDiscountItems.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblDiscountItems.setForeground(new Color(0, 0, 0));
			}
		});
		lblDiscountItems.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblDiscountItems.setBounds(871, 92, 109, 26);
		add(lblDiscountItems);
		
		JLabel lblChangeRole = new JLabel("Change Role");
		lblChangeRole.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showStaffMenuScreen(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblChangeRole.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblChangeRole.setForeground(new Color(0, 0, 0));
			}
		});
		lblChangeRole.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblChangeRole.setBounds(979, 92, 129, 26);
		add(lblChangeRole);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBounds(0, 93, 1120, 35);
		add(panel_4);
		panel_4.setBackground(new Color(255, 204, 255));

		
		JLabel lblName = new JLabel("Name:");
		lblName.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblName.setBounds(93, 219, 99, 26);
		add(lblName);
		
		JLabel lblPrice = new JLabel("Price:");
		lblPrice.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblPrice.setBounds(96, 416, 68, 26);
		add(lblPrice);
		
		JLabel lblStock = new JLabel("Stock:");
		lblStock.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblStock.setBounds(93, 465, 79, 22);
		add(lblStock);
		
		JLabel lblBrand = new JLabel("Brand:");
		lblBrand.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblBrand.setBounds(82, 370, 73, 19);
		add(lblBrand);
		
		JLabel lblAddImage = new JLabel("Image:");
		lblAddImage.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblAddImage.setBounds(539, 200, 129, 27);
		add(lblAddImage);
		
		this.label_1= new JLabel("");
		label_1.setBounds(657, 200, 349, 266);
		fileN = "icons/noimage.jpg";
		img2 = new ImageIcon(this.getClass().getResource("/noimage.jpg")).getImage().getScaledInstance(label_1.getWidth(), label_1.getHeight(), Image.SCALE_SMOOTH);
		label_1.setIcon(new ImageIcon(img2));

		add(label_1);
	    
		this.cbCat = new JComboBox(this.valArr);
		cbCat.setBackground(new Color(255, 255, 255));
		cbCat.setBounds(215, 319, 213, 26);
		add(cbCat);	
		
		textField = new JTextField();
		textField.setBackground(new Color(255, 255, 255));
		textField.setBounds(215, 222, 213, 26);
		add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBackground(new Color(255, 255, 255));
		textField_1.setBounds(215, 419, 213, 26);
		add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBackground(new Color(255, 255, 255));
		textField_2.setBounds(215, 369, 213, 26);
		add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBackground(new Color(255, 255, 255));
		textField_3.setBounds(215, 466, 213, 26);
		add(textField_3);
		textField_3.setColumns(10);
		
		JButton btnInsertImage = new JButton("Insert Image");
		btnInsertImage.setFont(new Font("Dialog", Font.PLAIN, 15));
		btnInsertImage.setBackground(new Color(255, 255, 255));
		btnInsertImage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser filechooser = new JFileChooser();
				filechooser.setCurrentDirectory(new File("src/ImageFile"));
				int response = filechooser.showOpenDialog(null);
				if (response == filechooser.APPROVE_OPTION){
					String fileName = new File(filechooser.getSelectedFile().getAbsolutePath()).getName();
					fileS = "src/ImageFile/" + fileName ;
					Image image = new ImageIcon(fileS).getImage().getScaledInstance(label_1.getWidth(), label_1.getHeight(), Image.SCALE_SMOOTH); //scale image
					label_1.setIcon( new ImageIcon(image)); //set image
					System.out.println(fileS);
					
				}
			}
		});	
		btnInsertImage.setBounds(746, 505, 163, 35);
		add(btnInsertImage);	
		
		textField_4 = new JTextField();
		textField_4.setBackground(new Color(255, 255, 255));
		textField_4.setBounds(215, 271, 213, 26);
		add(textField_4);
		textField_4.setColumns(10);
		
		JLabel lblExpiryDate = new JLabel("Expiry Date:");
		lblExpiryDate.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblExpiryDate.setBounds(35, 514, 140, 22);
		add(lblExpiryDate);
		
		this.dateChooser = new JDateChooser();
		dateChooser.setBackground(new Color(255, 255, 255));
		this.dateChooser.setBounds(215, 518, 213, 26);
		add(this.dateChooser);

		
		JButton btnCreate = new JButton("Create");
		btnCreate.setBackground(new Color(255, 255, 255));
		btnCreate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				try{ 
					String name = textField.getText();
					String desc = textField_4.getText();
					String brand = textField_2.getText();
					double price = Double.valueOf(textField_1.getText());
					int stock = Integer.valueOf(textField_3.getText());
					String cat = cbCat.getSelectedItem().toString();
					SimpleDateFormat spf = new SimpleDateFormat("dd-MMM-yy");
					String expdate = spf.format(dateChooser.getDate());
				
					if(fileS == null){
						fileSC = fileN;
					}
					else
					{
						fileSC = fileS;
						}
					
					main.getController().addItem(name, desc,  brand, price, stock, cat, expdate,fileSC);
			        
			        textField.setText("");
			        textField_4.setText("");
			        textField_1.setText("");
			        textField_2.setText("");
			        textField_3.setText("");
			        cbCat.setSelectedItem("Fresh Produce");
			        dateChooser.setDate(null);
			        img2 = new ImageIcon(this.getClass().getResource("/noimage.jpg")).getImage().getScaledInstance(label_1.getWidth(), label_1.getHeight(), Image.SCALE_SMOOTH);
					label_1.setIcon(new ImageIcon(img2));	
					
					}
					catch (IllegalArgumentException e){
						JOptionPane.showMessageDialog(null, "Please fill in all details correctly.","Incomplete Details", JOptionPane.OK_OPTION);
					}
//					catch (NullPointerException a){
//					JOptionPane.showMessageDialog(null, "Please change your price and stock to numbers.","Incorrect Details", JOptionPane.OK_OPTION);
//				}
	        
			}
		});
		btnCreate.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnCreate.setBounds(527, 599, 141, 53);
		add(btnCreate);
		
		JButton btnBack = new JButton("Back");
		btnBack.setBackground(new Color(255, 255, 255));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				main.showMDashboard(user1);
			}
		});
		btnBack.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnBack.setBounds(937, 599, 151, 53);
		add(btnBack);
		
		JButton btnViewItems = new JButton("View Items");
		btnViewItems.setBackground(new Color(255, 255, 255));
		btnViewItems.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				main.showMViewItems(user1);
			}
		});
		btnViewItems.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnViewItems.setBounds(719, 600, 175, 50);
		add(btnViewItems);
		
		JLabel lblItemDescription = new JLabel("Description:");
		lblItemDescription.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblItemDescription.setBounds(35, 264, 129, 35);
		add(lblItemDescription);
		
		JLabel lblCategory = new JLabel("Category:");
		lblCategory.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblCategory.setBounds(59, 312, 116, 35);
		add(lblCategory);

		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(248, 248, 255));
		panel_2.setBounds(25, 190, 471, 375);
		add(panel_2);
		

		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(248, 248, 255));
		panel_3.setBounds(527, 190, 561, 375);
		add(panel_3);
		
	}
}