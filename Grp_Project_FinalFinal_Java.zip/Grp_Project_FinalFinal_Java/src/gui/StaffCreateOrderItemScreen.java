package gui;


import javax.swing.JPanel;

import controller.MainFrame;
import data.Item;
import data.OrderItem;
import data.User;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.DefaultListModel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollBar;
import javax.swing.JTable;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.List;

import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import javax.swing.JToolBar;
import javax.swing.JTabbedPane;

public class StaffCreateOrderItemScreen extends JPanel{
	private MainFrame main;
 	private int index;
 	private JTable table;
 	private OrderItem[] orderItems;
 	private DefaultTableModel model;
 	private JLabel lblprice;
 	private JLabel lblNumOfItemInOrder;
 	private JLabel lblTime;
 	private JLabel lblDate;
 	private JLabel totalQuantityNum;
 	private JLabel lblTotalDiscountNum;
 	private User user;
 	
	public StaffCreateOrderItemScreen(MainFrame main, int index, User user) {
		
		this.main = main;
		this.user = user;
		this.index = index;
		
		setLayout(null);
		this.setSize(1120, 665);
		
		setBackground(new Color(253, 245, 230));
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(224, 255, 255));
		panel.setBounds(0, 0, 1120, 94);
		add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showStaffMenuScreen(user);
			}
		});
		lblNewLabel.setBounds(24, 18, 69, 62);
		Image img = new ImageIcon(this.getClass().getResource("/loginiconn.png")).getImage().getScaledInstance(lblNewLabel.getWidth(), lblNewLabel.getHeight(), Image.SCALE_SMOOTH);
		lblNewLabel.setIcon(new ImageIcon(img));	
		panel.add(lblNewLabel);
		
		JLabel lblGrocerySalesSystem = new JLabel("Joy Minimart");
		lblGrocerySalesSystem.setBackground(new Color(0, 0, 0));
		lblGrocerySalesSystem.setForeground(new Color(0, 0, 0));
		lblGrocerySalesSystem.setFont(new Font("Segoe UI Semilight", Font.BOLD, 50));
		lblGrocerySalesSystem.setBounds(386, 13, 355, 67);
		panel.add(lblGrocerySalesSystem);
		
		JLabel label = new JLabel("");
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showLogin();
			}
			
		});
		label.setBounds(1054, 29, 54, 42);
		Image img1 = new ImageIcon(this.getClass().getResource("/logout.png")).getImage().getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_SMOOTH);
		label.setIcon(new ImageIcon(img1));
		panel.add(label);
		
		JLabel lblWelcome = new JLabel("Welcome,");
		lblWelcome.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblWelcome.setBounds(833, 38, 77, 26);
		panel.add(lblWelcome);
		
		JLabel lblstaffName = new JLabel(user.getStaffName());
		lblstaffName.setBounds(923, 30, 119, 42);
		panel.add(lblstaffName);
		lblstaffName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		JPanel panel_1 = new JPanel();
		panel_1.setForeground(new Color(255, 204, 255));
		panel_1.setBackground(new Color(255, 215, 0));
		panel_1.setBounds(0, 93, 1120, 50);
		add(panel_1);
		panel_1.setLayout(null);
		
		String Number = String.valueOf(index);
		
		this.lblDate= new JLabel("date");
		this.lblDate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		this.lblDate.setBounds(12, 5, 166, 43);
		panel_1.add(this.lblDate);
		
		this.lblTime = new JLabel("Time");
		this.lblTime.setFont(new Font("Tahoma", Font.PLAIN, 20));
		this.lblTime.setBounds(180, 5, 145, 43);
		panel_1.add(this.lblTime);
		
		JLabel lblCreateOrder = new JLabel("Create Order");
		lblCreateOrder.setForeground(Color.BLACK);
		lblCreateOrder.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblCreateOrder.setBounds(479, 0, 172, 50);
		panel_1.add(lblCreateOrder);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(559, 204, 536, 353);
		add(scrollPane);
		
		this.table = new JTable(model);
		
		Object[] columns = {
				"Name", "Quantity", "Price per item", "Discount per item"
			};
		this.model = new DefaultTableModel(0,3);
		this.model.setColumnIdentifiers(columns);
		
		scrollPane.setViewportView(table);
		this.populateTable();
		
		JButton btnNewButton_1 = new JButton("Check Out");
		btnNewButton_1.setBackground(new Color(255, 255, 255));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				main.getController().updateStockRemain(index);
				main.getController().setStaffNameNumOrder(index, user.getStaffName());
				System.out.println("staff name is "+ user.getStaffName());
				JOptionPane.showMessageDialog(null, "Proceed to payment", "Payment", JOptionPane.PLAIN_MESSAGE);
				main.showReceipt(index,user); 
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnNewButton_1.setBounds(915, 574, 180, 78);
		add(btnNewButton_1);
		
		JLabel lblTotalPriceIs = new JLabel("Total Price : $");
		lblTotalPriceIs.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTotalPriceIs.setBounds(22, 590, 134, 29);
		add(lblTotalPriceIs);
		

		String totalPrice = main.getController().getTotalPrice(index);
		this.lblprice= new JLabel(totalPrice);
		this.lblprice.setFont(new Font("Tahoma", Font.PLAIN, 20));
		this.lblprice.setBounds(168, 594, 83, 25);
		add(this.lblprice);
		
		JLabel lblTotalItem = new JLabel("Total Item :");
		lblTotalItem.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTotalItem.setBounds(22, 617, 115, 35);
		add(lblTotalItem);
		
        int number = main.getController().getOrderSize(index);
        String numberS = String.valueOf(number);
		this.lblNumOfItemInOrder = new JLabel(numberS);
		this.lblNumOfItemInOrder.setFont(new Font("Tahoma", Font.PLAIN, 20));
		this.lblNumOfItemInOrder.setBounds(138, 620, 92, 29);
		add(this.lblNumOfItemInOrder);
		
		JLabel lblNewLabel_1 = new JLabel("Total Quantity :");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(260, 590, 144, 29);
		add(lblNewLabel_1);
		
		int totalQuantity = main.getController().getOrderTotalQuantity(index);
		String totalQuantityS = String.valueOf(totalQuantity);
		this.totalQuantityNum = new JLabel(totalQuantityS);
		this.totalQuantityNum.setFont(new Font("Tahoma", Font.PLAIN, 20));
		this.totalQuantityNum.setBounds(409, 590, 73, 29);
		add(this.totalQuantityNum);
		
		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBackground(Color.WHITE);
		panel_2.setBounds(10, 178, 531, 399);
		add(panel_2);
		
		JLabel lblTotalDiscount = new JLabel("Total Discount :");
		lblTotalDiscount.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTotalDiscount.setBounds(260, 627, 144, 25);
		add(lblTotalDiscount);
		
		String totalDis = main.getController().getOrderTotalDis(index);
		this.lblTotalDiscountNum = new JLabel(totalDis);
		this.lblTotalDiscountNum.setFont(new Font("Tahoma", Font.PLAIN, 20));
		this.lblTotalDiscountNum.setBounds(409, 623, 92, 29);
		add(this.lblTotalDiscountNum);
		
		JButton button = new JButton("Fresh Produce");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{

					String[] selectionsFPItems = main.getController().getSelectionsFPItems();
			        Object val = JOptionPane.showInputDialog(null, "Choose one",
			            "Input", JOptionPane.INFORMATION_MESSAGE, null,
			            selectionsFPItems, selectionsFPItems[0]);
			        String name = String.valueOf(val);
			        int iStock = main.getController().getItemStockRemain(name);
			        int quantity = selectQuantity(iStock);
			        main.getController().addOrderItem(index, name, quantity);
			        populateTable();
			        setDetailsOnScreen();
			        
				}
				catch(ArrayIndexOutOfBoundsException a){
					JOptionPane.showMessageDialog(null, "There are no items of this category.", "Error message", JOptionPane.PLAIN_MESSAGE);
				}

			}
		});
		button.setFont(new Font("Dialog", Font.BOLD, 12));
		button.setBackground(Color.GREEN);
		button.setBounds(28, 13, 139, 115);
		panel_2.add(button);
		
		JButton button_1 = new JButton("Food Cupboard");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					
						String[] selectionsFCItems = main.getController().getSelectionsFCItems();
				        Object val = JOptionPane.showInputDialog(null, "Choose one",
				            "Input", JOptionPane.INFORMATION_MESSAGE, null,
				            selectionsFCItems, selectionsFCItems[0]);
				        String name = String.valueOf(val);
				        int iStock = main.getController().getItemStockRemain(name);
				        int quantity = selectQuantity(iStock);
				        main.getController().addOrderItem(index, name, quantity);
				        populateTable();
				        setDetailsOnScreen();
						
				}
				catch(ArrayIndexOutOfBoundsException b){
					JOptionPane.showMessageDialog(null, "There are no items of this category.", "Error message", JOptionPane.PLAIN_MESSAGE);
				}

			}
		});
		button_1.setFont(new Font("Dialog", Font.BOLD, 12));
		button_1.setBackground(Color.MAGENTA);
		button_1.setBounds(186, 13, 144, 115);
		panel_2.add(button_1);
		
		JButton button_2 = new JButton("Snacks");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					try{

							String[] selectionsSNItems = main.getController().getSelectionsSNItems();
					        Object val = JOptionPane.showInputDialog(null, "Choose one",
					            "Input", JOptionPane.INFORMATION_MESSAGE, null,
					            selectionsSNItems, selectionsSNItems[0]);
					        String name = String.valueOf(val);
					        int iStock = main.getController().getItemStockRemain(name);
					        int quantity = selectQuantity(iStock);
					        main.getController().addOrderItem(index, name, quantity);
					        populateTable();
					        setDetailsOnScreen();
						
					}

				catch(ArrayIndexOutOfBoundsException c){
					JOptionPane.showMessageDialog(null, "There are no items of this category.", "Error message", JOptionPane.PLAIN_MESSAGE);
				}

			}
		});
		button_2.setFont(new Font("Dialog", Font.BOLD, 12));
		button_2.setBackground(Color.CYAN);
		button_2.setBounds(357, 13, 139, 115);
		panel_2.add(button_2);
		
		JButton button_3 = new JButton("Drinks");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{

						String[] selectionsDRItems = main.getController().getSelectionsDRItems();
				        Object val = JOptionPane.showInputDialog(null, "Choose one",
				            "Input", JOptionPane.INFORMATION_MESSAGE, null,
				            selectionsDRItems, selectionsDRItems[0]);
				        String name = String.valueOf(val);
				        int iStock = main.getController().getItemStockRemain(name);
				        int quantity = selectQuantity(iStock);
				        main.getController().addOrderItem(index, name, quantity);
				        populateTable();
				        setDetailsOnScreen();
						
				}
				catch(ArrayIndexOutOfBoundsException d){
					JOptionPane.showMessageDialog(null, "There are no items of this category.", "Error message", JOptionPane.PLAIN_MESSAGE);
				}

			}
		});
		button_3.setFont(new Font("Dialog", Font.BOLD, 12));
		button_3.setBackground(Color.RED);
		button_3.setBounds(28, 141, 139, 115);
		panel_2.add(button_3);
		
		JButton button_4 =new JButton("Frozen Products");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					
						String[] selectionsFrozenPItems = main.getController().getSelectionsFrozenPItems();
				        Object val = JOptionPane.showInputDialog(null, "Choose one",
				            "Input", JOptionPane.INFORMATION_MESSAGE, null,
				            selectionsFrozenPItems, selectionsFrozenPItems[0]);
				        String name = String.valueOf(val);
				        int iStock = main.getController().getItemStockRemain(name);
				        int quantity = selectQuantity(iStock);
				        main.getController().addOrderItem(index, name, quantity);
				        populateTable();
				        setDetailsOnScreen();
						
				}
				catch(ArrayIndexOutOfBoundsException f){
					JOptionPane.showMessageDialog(null, "There are no items of this category.", "Error message", JOptionPane.PLAIN_MESSAGE);
				}

			}
		});
		button_4.setFont(new Font("Dialog", Font.BOLD, 12));
		button_4.setBackground(Color.YELLOW);
		button_4.setBounds(186, 141, 144, 115);
		panel_2.add(button_4);
		
		JButton button_5 = new JButton("Others");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{

						String[] selectionsOTItems = main.getController().getSelectionsOTItems();
				        Object val = JOptionPane.showInputDialog(null, "Choose one",
				            "Input", JOptionPane.INFORMATION_MESSAGE, null,
				            selectionsOTItems, selectionsOTItems[0]);
				        String name = String.valueOf(val);
				        int iStock = main.getController().getItemStockRemain(name);
				        int quantity = selectQuantity(iStock);
				        main.getController().addOrderItem(index, name, quantity);
				        populateTable();
				        setDetailsOnScreen();
						
				}
				catch(ArrayIndexOutOfBoundsException g){
					JOptionPane.showMessageDialog(null, "There are no items of this category.", "Error message", JOptionPane.PLAIN_MESSAGE);
				}

			}
		});
		button_5.setFont(new Font("Dialog", Font.BOLD, 12));
		button_5.setBackground(new Color(176, 224, 230));
		button_5.setBounds(357, 141, 139, 115);
		panel_2.add(button_5);
		
		JButton button_6 = new JButton("Discounted Items");
		button_6.setFont(new Font("Dialog", Font.BOLD, 12));
		button_6.setBackground(Color.ORANGE);
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{

					String[] selectionsDisItems = main.getController().getSelectionsDisItems();
			        Object val = JOptionPane.showInputDialog(null, "Choose one",
			            "Input", JOptionPane.INFORMATION_MESSAGE, null,
			            selectionsDisItems, selectionsDisItems[0]);
			        String name = String.valueOf(val);
			        int iStock = main.getController().getItemStockRemain(name);
			        int quantity = selectQuantity(iStock);
			        main.getController().addOrderItem(index, name, quantity);
			        populateTable();
			        setDetailsOnScreen();
					
			}
			catch(ArrayIndexOutOfBoundsException d){
				JOptionPane.showMessageDialog(null, "There are no items of this category.", "Error message", JOptionPane.PLAIN_MESSAGE);
			}
			}
		});
		button_6.setBounds(28, 269, 139, 115);
		panel_2.add(button_6);
		
		Icon icon1 = new ImageIcon("icons/delete.png");
		JButton btnDelete = new JButton(icon1);
		btnDelete.setFont(new Font("Dialog", Font.BOLD, 12));
		btnDelete.setText("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int i = table.getSelectedRow();
				
				if (i == -1){
					JOptionPane.showMessageDialog(null, "select the row to delete", "Error message", JOptionPane.PLAIN_MESSAGE);
				}
				else{
					System.out.println("row num in delete"+ i);
					main.getController().deleteOrderItem(index, i);
				}
				populateTable();
				setDetailsOnScreen();
			}
		});
		btnDelete.setBounds(186, 269, 144, 115);
		panel_2.add(btnDelete);
	
		Icon icon = new ImageIcon("icons/edit.png");
		JButton btnNewBut = new JButton(icon);
		btnNewBut.setFont(new Font("Dialog", Font.BOLD, 12));
		btnNewBut.setText("Edit");
		btnNewBut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int indexT = table.getSelectedRow();
				System.out.println("indexT in edit is " + indexT);
				String namei = model.getValueAt(indexT, 0).toString();
				int iStock = main.getController().getItemStockRemain(namei);
		        int quantity = selectQuantity(iStock);
		        main.getController().editOrderItem(index, indexT, namei, quantity);
		        populateTable();
		        setDetailsOnScreen();
				}
		});
		btnNewBut.setBounds(357, 269, 139, 115);
		panel_2.add(btnNewBut);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				main.showStaffMenuScreen(user);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 35));
		btnNewButton.setBounds(559, 574, 180, 78);
		add(btnNewButton);
		
		JButton btnNewButton_2 = new JButton("Clear All");
		btnNewButton_2.setBackground(new Color(255, 255, 255));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				main.getController().clearOrderItem(index);
				populateTable();
				setDetailsOnScreen();
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnNewButton_2.setBounds(736, 574, 180, 78);
		add(btnNewButton_2);
		
		
		
		JLabel lblOrder = new JLabel("Order");
		lblOrder.setBounds(721, 145, 88, 46);
		add(lblOrder);
		lblOrder.setFont(new Font("Tahoma", Font.PLAIN, 35));
		
		JLabel lblnumber = new JLabel(Number);
		lblnumber.setBounds(821, 145, 95, 46);
		add(lblnumber);
		lblnumber.setFont(new Font("Tahoma", Font.PLAIN, 35));
		
		setCurrDateTime();
	}
	private void populateTable(){
		this.model.setRowCount(0);

		this.orderItems = this.main.getController().getAllOrderItems(this.index);
		Object[] row = new Object[4];
		DecimalFormat decfor = new DecimalFormat("0.00");
		for(int i = 0; i < this.orderItems.length; i++){
			OrderItem op = this.orderItems[i];
			row[0] = op.getName();
			row[1] = op.getQuantity();
			row[2] = decfor.format(op.getPrice());
			row[3] = decfor.format(op.getDiscount());
			
			System.out.println("row[0]"+row[0]);
			System.out.println(row[1]);
			System.out.println(row[2]);
			System.out.println(row[3]);
			
			this.model.addRow(row);
			
		}
		this.table.setModel(this.model);
		

	}
	private int selectQuantity(int stock){
		
		String bigList[] = new String[stock];

	    for (int i = 0; i < bigList.length; i++) {
	      bigList[i] = Integer.toString(i+1);
	    }

	    Object q = JOptionPane.showInputDialog(this, "Pick a quantity", "Input", JOptionPane.QUESTION_MESSAGE,
	        null, bigList, "Titan");
	    Integer quantity = Integer.parseInt(q.toString());
	    return quantity;

	}
	
	private void setCurrDateTime(){
		DateTimeFormatter datef = DateTimeFormatter.ofPattern("dd-MMM-yy");
		DateTimeFormatter timef = DateTimeFormatter.ofPattern("HH:mm:ss");
		LocalDate ld = LocalDate.now();
		LocalTime lt = LocalTime.now();
		lblDate.setText(ld.format(datef));
		lblTime.setText(lt.format(timef));
		main.getController().saveDateTime(index, ld.format(datef), lt.format(timef));
		
		
	}
	
	private void setDetailsOnScreen(){
		int number = main.getController().getOrderSize(index); //set total item
        String numberS = String.valueOf(number);
        lblNumOfItemInOrder.setText(numberS);
		int totalQuantity = main.getController().getOrderTotalQuantity(index); //set total quantity
		String totalQuantityS = String.valueOf(totalQuantity);
		totalQuantityNum.setText(totalQuantityS);
		String totalPrice = main.getController().getTotalPrice(index); //set total price
		String totalPriceS = String.valueOf(totalPrice);
		lblprice.setText(totalPriceS);
		String totalDis = main.getController().getOrderTotalDis(index); //set total discount
		String totalDisS = String.valueOf(totalDis);
		lblTotalDiscountNum.setText(totalDisS);
	}

}
