package gui;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

class MyTableCellRender extends DefaultTableCellRenderer 
{
    public MyTableCellRender() 
    {
        super();
        setOpaque(true);
    } 
    public Component getTableCellRendererComponent(JTable table, Object value, 
            boolean isSelected, boolean hasFocus, int row, int column) 
    { 
        if((int)(table.getValueAt(row, 4)) != 0)
        {

            setBackground(Color.white);    
            setForeground(Color.black);
        }    
        else
        {    
            setForeground(Color.black);        
            setBackground(Color.red);   
        } 
        setText(value !=null ? value.toString() : "");
        return this;
    }
}
