package gui;

import javax.swing.JPanel;

import controller.MainFrame;
import data.Item;
import data.User;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.toedter.calendar.JDateChooser;

public class ManagerDiscountScreen extends JPanel{
	private MainFrame main;
	private JTextField textField;
	private JTable table;
	private JComboBox selectitemcb, datestartcb, dateendcb;
	private String[] itemArr;
	private Item[] items;
	private DefaultTableModel model;
	private JLabel lblNewLabel_1;
	private Image img2;
	private JDateChooser dateChooser;
	private JDateChooser dateChooser_1;
	private User user1;
	
	public ManagerDiscountScreen(MainFrame main, User user) {
		this.main = main;
		this.user1 = user;
		setLayout(null);
		this.setSize(1120, 665);
		
		setBackground(new Color(255, 240, 245));
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(221, 160, 221));
		panel.setBounds(0, 0, 1120, 94);
		add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMDashboard(user1);
			}
		});
		lblNewLabel.setBounds(24, 18, 69, 62);
		Image img = new ImageIcon(this.getClass().getResource("/loginiconn.png")).getImage().getScaledInstance(lblNewLabel.getWidth(), lblNewLabel.getHeight(), Image.SCALE_SMOOTH);
		lblNewLabel.setIcon(new ImageIcon(img));	
		panel.add(lblNewLabel);
		
		JLabel lblGrocerySalesSystem = new JLabel("Joy Minimart");
		lblGrocerySalesSystem.setForeground(new Color(139, 0, 139));
		lblGrocerySalesSystem.setFont(new Font("Segoe UI Semilight", Font.BOLD, 50));
		lblGrocerySalesSystem.setBounds(386, 13, 355, 67);
		panel.add(lblGrocerySalesSystem);
		
		JLabel label = new JLabel("");
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showLogin();
			}
			
		});
		label.setBounds(1054, 29, 54, 42);
		Image img1 = new ImageIcon(this.getClass().getResource("/logout.png")).getImage().getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_SMOOTH);
		label.setIcon(new ImageIcon(img1));
		panel.add(label);
		
		JLabel label_2 = new JLabel(user.getStaffName());
		label_2.setBounds(922, 29, 104, 42);
		panel.add(label_2);
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		JLabel lblWelcome = new JLabel("Welcome,");
		lblWelcome.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblWelcome.setBounds(833, 38, 77, 26);
		panel.add(lblWelcome);
		
		JPanel panel_1 = new JPanel();
		panel_1.setForeground(new Color(255, 204, 255));
		panel_1.setBackground(new Color(224, 255, 255));
		panel_1.setBounds(0, 121, 1120, 50);
		add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblItemDetails = new JLabel("Discount");
		lblItemDetails.setForeground(new Color(0, 0, 0));
		lblItemDetails.setBounds(451, 0, 121, 50);
		panel_1.add(lblItemDetails);
		lblItemDetails.setFont(new Font("Tahoma", Font.BOLD, 25));
		
		JLabel lblHome = new JLabel("Home");
		lblHome.setForeground(new Color(0, 0, 0));

		lblHome.setBackground(new Color(240, 255, 255));
		lblHome.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				main.showMDashboard(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblHome.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblHome.setForeground(new Color(0, 0, 0));
			}
		});
		lblHome.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblHome.setBounds(10, 92, 56, 26);
		add(lblHome);
		
		JLabel lblCreateItems = new JLabel("Create Items");
		lblCreateItems.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMCreateScreen(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblCreateItems.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblCreateItems.setForeground(new Color(0, 0, 0));
			}
			
		});
		lblCreateItems.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblCreateItems.setBounds(86, 92, 116, 26);
		add(lblCreateItems);
		
		JLabel lblViewItems = new JLabel("View Items");
		lblViewItems.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMViewItems(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblViewItems.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblViewItems.setForeground(new Color(0, 0, 0));
			}
		});
		lblViewItems.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblViewItems.setBounds(229, 92, 109, 26);
		add(lblViewItems);
		
		JLabel lblViewSaleSummary = new JLabel("View Sale Summary");
		lblViewSaleSummary.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMSaleSummary(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblViewSaleSummary.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblViewSaleSummary.setForeground(new Color(0, 0, 0));
			}
		});
		lblViewSaleSummary.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblViewSaleSummary.setBounds(360, 92, 195, 26);
		add(lblViewSaleSummary);
		
		JLabel lblTrackInventory = new JLabel("Track Inventory");
		lblTrackInventory.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMInventory(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblTrackInventory.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblTrackInventory.setForeground(new Color(0, 0, 0));
			}
		});
		lblTrackInventory.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTrackInventory.setBounds(567, 92, 140, 26);
		add(lblTrackInventory);
		
		JLabel lblViewOrders = new JLabel("View Orders");
		lblViewOrders.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMViewOrders(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblViewOrders.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblViewOrders.setForeground(new Color(0, 0, 0));
			}
		});
		lblViewOrders.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblViewOrders.setBounds(733, 92, 116, 26);
		add(lblViewOrders);
		
		JLabel lblDiscountItems = new JLabel("Discount");
		lblDiscountItems.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMDiscount(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblDiscountItems.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblDiscountItems.setForeground(new Color(0, 0, 0));
			}
		});
		lblDiscountItems.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblDiscountItems.setBounds(871, 92, 109, 26);
		add(lblDiscountItems);
		
		JLabel lblChangeRole = new JLabel("Change Role");
		lblChangeRole.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showStaffMenuScreen(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblChangeRole.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblChangeRole.setForeground(new Color(0, 0, 0));
			}
		});
		lblChangeRole.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblChangeRole.setBounds(979, 92, 129, 26);
		add(lblChangeRole);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBounds(0, 93, 1120, 35);
		add(panel_4);
		panel_4.setBackground(new Color(255, 204, 255));

		
		JButton button = new JButton("Back");
		button.setBackground(new Color(255, 255, 255));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				main.showMDashboard(user1);
			}
		});
		button.setFont(new Font("Tahoma", Font.BOLD, 15));
		button.setBounds(965, 587, 132, 51);
		add(button);
		
		JLabel lblSelectItem = new JLabel("Select Item:");
		lblSelectItem.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblSelectItem.setBounds(74, 242, 195, 36);
		add(lblSelectItem);
		
		String [] itemArr = main.getController().getAllItemNames();
		this.selectitemcb = new JComboBox(itemArr);
		selectitemcb.setBackground(new Color(255, 255, 255));
		selectitemcb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String iname = selectitemcb.getSelectedItem().toString();
				
				String pic = main.getController().getItemImage(iname);
				Image image3 = new ImageIcon(pic).getImage().getScaledInstance(lblNewLabel_1.getWidth(), lblNewLabel_1.getHeight(), Image.SCALE_SMOOTH); //scale image
				lblNewLabel_1.setIcon( new ImageIcon(image3)); //set image
				
				float Idis = main.getController().getItemDiscount(iname);
				DecimalFormat decfor = new DecimalFormat("0.00");
				textField.setText("" + decfor.format(Idis));
			}
		});
		selectitemcb.setBounds(245, 244, 215, 34);
		add(selectitemcb);
		
		JLabel lblDiscount_1 = new JLabel("Discount (%):");
		lblDiscount_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblDiscount_1.setBounds(56, 315, 148, 50);
		add(lblDiscount_1);
		
		textField = new JTextField();
		textField.setBackground(new Color(255, 255, 255));
		textField.setBounds(245, 325, 215, 36);
		add(textField);
		textField.setColumns(10);
		
		JLabel lblDate = new JLabel("Date:");
		lblDate.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblDate.setBounds(137, 405, 104, 50);
		add(lblDate);
		
		JLabel lblFrom = new JLabel("From");
		lblFrom.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblFrom.setBounds(231, 422, 56, 16);
		add(lblFrom);
		
		JLabel lblTo = new JLabel("To");
		lblTo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTo.setBounds(231, 510, 56, 16);
		add(lblTo);
		
		 dateChooser= new JDateChooser();
		 dateChooser.setBackground(new Color(255, 255, 255));
		dateChooser.setDateFormatString("dd MMMM, yyyy");
		dateChooser.setBounds(299, 417, 215, 36);
		add(dateChooser);
		dateChooser.getJCalendar().setPreferredSize(new Dimension(600, 500));
		
		dateChooser_1 = new JDateChooser();
		dateChooser_1.setBackground(new Color(255, 255, 255));
		dateChooser_1.setDateFormatString("dd MMMM, yyyy");
		dateChooser_1.setBounds(299, 498, 215, 36);
		add(dateChooser_1);
		dateChooser_1.getJCalendar().setPreferredSize(new Dimension(600, 500));
		
		JButton btnApply = new JButton("Apply");
		btnApply.setBackground(new Color(255, 255, 255));
		btnApply.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					String disI = selectitemcb.getSelectedItem().toString();
					float disc = Float.valueOf(textField.getText());
					SimpleDateFormat spf = new SimpleDateFormat("dd-MMM-yy");
					String sDate = spf.format(dateChooser.getDate());
					String eDate = spf.format(dateChooser_1.getDate());
					
				    int option = JOptionPane.showConfirmDialog(null, "Confirm discount?");
				    if (option == 0){
				    JOptionPane.showMessageDialog(null, "Discount has been applied.", "Item Discount", 1, null);// 0=yes, 1=no, 2=cancel
				    Item disItem = new Item(disc, sDate, eDate);
				    main.getController().discountItem(disI, disc, sDate, eDate);

				    populateJTable();
				    textField.setText("");
				    dateChooser.setCalendar(null);
				    dateChooser_1.setCalendar(null);
				    selectitemcb.setSelectedItem(itemArr);
				    }
				    
				}
				catch(Exception a){
					JOptionPane.showMessageDialog(null, "Please fill in all details correctly.", "Missing Details", JOptionPane.OK_OPTION);
				}
			}
		});
		btnApply.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnApply.setBounds(232, 574, 148, 50);
		add(btnApply);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(600, 477, 483, 84);
		add(scrollPane);
		
		this.table = new JTable(model);
		//table.setFont(new Font("Tahoma", Font.PLAIN, 20));
		Object[] columns = { "Item", "Price", "Discounted Price"};
		this.model = new DefaultTableModel();
		model.setColumnIdentifiers(columns);
		//table.setRowHeight(0, 50);
		scrollPane.setViewportView(table);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(248, 248, 255));
		panel_2.setBounds(32, 200, 540, 361);
		add(panel_2);
		
		lblNewLabel_1= new JLabel("");
		lblNewLabel_1.setBounds(612, 200, 453, 268);
		img2 = new ImageIcon(this.getClass().getResource("/noimage.jpg")).getImage().getScaledInstance(lblNewLabel_1.getWidth(), lblNewLabel_1.getHeight(), Image.SCALE_SMOOTH);
		lblNewLabel_1.setIcon(new ImageIcon(img2));	
		add(lblNewLabel_1);
		
	}
	
	public void populateJTable(){
		
		model.setRowCount(0);
		this.items = this.main.getController().getAllItems();
		Object[] row = new Object[4];
		DecimalFormat decfor = new DecimalFormat("0.00");
		
		for(int i=0; i<items.length; i++){
			Item op = items[i];
			if(op.getItemName()==selectitemcb.getSelectedItem()){
				row[0] = op.getItemName();
				row[1] = op.getItemPrice();
				row[2] = decfor.format(op.getItemPrice()*((100-Float.valueOf(textField.getText()))/100));
			}	
		}
		model.addRow(row);
		this.table.setModel(model);
	}
	
}