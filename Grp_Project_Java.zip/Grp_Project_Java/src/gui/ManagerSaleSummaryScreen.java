package gui;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.table.DefaultTableModel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.DefaultXYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import com.toedter.calendar.JDayChooser;

import controller.MainFrame;
import data.Item;
import data.OrderDetail;
import data.User;

import javax.swing.JProgressBar;
import com.toedter.calendar.JDateChooser;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.SwingConstants;
import java.awt.Component;
import javax.swing.JTabbedPane;
import javax.swing.JScrollBar;

public class ManagerSaleSummaryScreen extends JPanel{
	
	private JTable table;
	private MainFrame main;
	private User user1;
	private DefaultTableModel model;
	private OrderDetail[] orders;
	private OrderDetail[] od;
	private JLabel lblDate;
	private JLabel lblTime;
	private Map<String,List<Double>>  sales;
	private JLabel lbltsale, tor, tquan, tnet, ttax, tdis;
	private LocalDate ld ;
	private JPanel panel_9;
	
	public ManagerSaleSummaryScreen(MainFrame main, User user) {
		
		this.main = main;
		this.user1 = user;
		setLayout(null);
		this.setSize(1120, 665);
		
		setForeground(Color.RED);
		
		setBackground(new Color(255, 240, 245));
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(221, 160, 221));
		panel.setBounds(0, 0, 1120, 94);
		add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMDashboard(user1);
			}
		});
		lblNewLabel.setBounds(24, 18, 69, 62);
		Image img = new ImageIcon(this.getClass().getResource("/loginiconn.png")).getImage().getScaledInstance(lblNewLabel.getWidth(), lblNewLabel.getHeight(), Image.SCALE_SMOOTH);
		lblNewLabel.setIcon(new ImageIcon(img));	
		panel.add(lblNewLabel);
		
		JLabel lblGrocerySalesSystem = new JLabel("Joy Minimart");
		lblGrocerySalesSystem.setForeground(new Color(139, 0, 139));
		lblGrocerySalesSystem.setFont(new Font("Segoe UI Semilight", Font.BOLD, 50));
		lblGrocerySalesSystem.setBounds(386, 13, 355, 67);
		panel.add(lblGrocerySalesSystem);
		
		JLabel label = new JLabel("");
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showLogin();
			}
			
		});
		label.setBounds(1054, 29, 54, 42);
		Image img1 = new ImageIcon(this.getClass().getResource("/logout.png")).getImage().getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_SMOOTH);
		label.setIcon(new ImageIcon(img1));
		panel.add(label);
		
		JLabel label_2 = new JLabel(user.getStaffName());
		label_2.setBounds(922, 29, 104, 42);
		panel.add(label_2);
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		JLabel lblWelcome = new JLabel("Welcome,");
		lblWelcome.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblWelcome.setBounds(833, 38, 77, 26);
		panel.add(lblWelcome);
		
		JPanel panel_1 = new JPanel();
		panel_1.setForeground(new Color(255, 204, 255));
		panel_1.setBackground(new Color(224, 255, 255));
		panel_1.setBounds(0, 121, 1120, 50);
		add(panel_1);
		panel_1.setLayout(null);
		
		this.lblDate= new JLabel("date");
		this.lblDate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		this.lblDate.setBounds(12, 5, 166, 43);
		panel_1.add(this.lblDate);
		
		this.lblTime = new JLabel("Time");
		this.lblTime.setFont(new Font("Tahoma", Font.PLAIN, 20));
		this.lblTime.setBounds(180, 5, 145, 43);
		panel_1.add(this.lblTime);
		
		JLabel lblItemDetails = new JLabel("View Sale Summary");
		lblItemDetails.setForeground(new Color(0, 0, 0));
		lblItemDetails.setBounds(416, 0, 260, 50);
		panel_1.add(lblItemDetails);
		lblItemDetails.setFont(new Font("Tahoma", Font.BOLD, 25));
		
		JLabel lblHome = new JLabel("Home");
		lblHome.setForeground(new Color(0, 0, 0));

		lblHome.setBackground(new Color(240, 255, 255));
		lblHome.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				main.showMDashboard(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblHome.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblHome.setForeground(new Color(0, 0, 0));
			}
		});
		lblHome.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblHome.setBounds(10, 92, 56, 26);
		add(lblHome);
		
		JLabel lblCreateItems = new JLabel("Create Items");
		lblCreateItems.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMCreateScreen(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblCreateItems.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblCreateItems.setForeground(new Color(0, 0, 0));
			}
			
		});
		lblCreateItems.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblCreateItems.setBounds(86, 92, 116, 26);
		add(lblCreateItems);
		
		JLabel lblViewItems = new JLabel("View Items");
		lblViewItems.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMViewItems(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblViewItems.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblViewItems.setForeground(new Color(0, 0, 0));
			}
		});
		lblViewItems.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblViewItems.setBounds(229, 92, 109, 26);
		add(lblViewItems);
		
		JLabel lblViewSaleSummary = new JLabel("View Sale Summary");
		lblViewSaleSummary.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMSaleSummary(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblViewSaleSummary.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblViewSaleSummary.setForeground(new Color(0, 0, 0));
			}
		});
		lblViewSaleSummary.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblViewSaleSummary.setBounds(360, 92, 195, 26);
		add(lblViewSaleSummary);
		
		JLabel lblTrackInventory = new JLabel("Track Inventory");
		lblTrackInventory.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMInventory(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblTrackInventory.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblTrackInventory.setForeground(new Color(0, 0, 0));
			}
		});
		lblTrackInventory.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTrackInventory.setBounds(567, 92, 140, 26);
		add(lblTrackInventory);
		
		JLabel lblViewOrders = new JLabel("View Orders");
		lblViewOrders.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMViewOrders(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblViewOrders.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblViewOrders.setForeground(new Color(0, 0, 0));
			}
		});
		lblViewOrders.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblViewOrders.setBounds(733, 92, 116, 26);
		add(lblViewOrders);
		
		JLabel lblDiscountItems = new JLabel("Discount");
		lblDiscountItems.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMDiscount(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblDiscountItems.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblDiscountItems.setForeground(new Color(0, 0, 0));
			}
		});
		lblDiscountItems.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblDiscountItems.setBounds(871, 92, 109, 26);
		add(lblDiscountItems);
		
		JLabel lblChangeRole = new JLabel("Change Role");
		lblChangeRole.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showStaffMenuScreen(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblChangeRole.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblChangeRole.setForeground(new Color(0, 0, 0));
			}
		});
		lblChangeRole.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblChangeRole.setBounds(979, 92, 129, 26);
		add(lblChangeRole);
		
		JPanel panel_view = new JPanel();
		panel_view.setBounds(0, 93, 1120, 35);
		add(panel_view);
		panel_view.setBackground(new Color(255, 204, 255));

		
//		JScrollPane scrollPane = new JScrollPane();
//		scrollPane.setBounds(39, 313, 1037, 259);
//		add(scrollPane);
//		
//		this.table = new JTable(model);
//		Object[] columns = {"Date", "Time", "Order No.", "Total Sales", "Net Sales",  "GST", "Discounts", "Total Items Sold"};
//		this.model = new DefaultTableModel();
//		model.setColumnIdentifiers(columns);
//		scrollPane.setViewportView(table);
		
		JButton btnNewButton = new JButton("Export");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 40));
		btnNewButton.setBounds(29, 747, 229, 88);
		add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				main.showLogin();
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 40));
		btnNewButton_1.setBounds(1005, 733, 268, 84);
		add(btnNewButton_1);
		
		this.lbltsale = new JLabel("$0");
		lbltsale.setBackground(new Color(0, 255, 255));
		lbltsale.setAlignmentX(Component.CENTER_ALIGNMENT);
		lbltsale.setForeground(new Color(255, 255, 255));
		lbltsale.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lbltsale.setBounds(213, 239, 140, 73);
		add(this.lbltsale);
        
		JPanel panel_2 = new JPanel();
		panel_2.setForeground(new Color(0, 0, 0));
		panel_2.setBackground(new Color(199, 21, 133));
		panel_2.setBounds(186, 212, 177, 100);
		add(panel_2);
		
		JLabel lblTotalSales = new JLabel("Total Sales");
		lblTotalSales.setForeground(new Color(255, 255, 255));
		lblTotalSales.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblTotalSales.setBackground(Color.WHITE);
		panel_2.add(lblTotalSales);
		
		this.tnet = new JLabel("$0");
		tnet.setBackground(new Color(0, 255, 255));
		tnet.setForeground(new Color(255, 255, 255));
		tnet.setFont(new Font("Tahoma", Font.PLAIN, 30));
		tnet.setBounds(403, 239, 156, 73);
		add(this.tnet);
		
		JPanel panel_3 = new JPanel();
		panel_3.setForeground(new Color(0, 0, 0));
		panel_3.setBackground(new Color(199, 21, 133));
		panel_3.setBounds(375, 212, 184, 100);
		add(panel_3);
		
		JLabel lblNetSales = new JLabel("Net Sales");
		lblNetSales.setForeground(new Color(255, 255, 255));
		lblNetSales.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNetSales.setBackground(Color.WHITE);
		panel_3.add(lblNetSales);
		
		this.ttax = new JLabel("$0");
		ttax.setBackground(new Color(0, 255, 255));
		ttax.setForeground(new Color(255, 255, 255));
		ttax.setFont(new Font("Tahoma", Font.PLAIN, 30));
		ttax.setBounds(611, 239, 144, 73);
		add(this.ttax);
		
		JPanel panel_4 = new JPanel();
		panel_4.setForeground(new Color(0, 0, 0));
		panel_4.setBackground(new Color(199, 21, 133));
		panel_4.setBounds(572, 212, 191, 100);
		add(panel_4);
		
		JLabel lblGst = new JLabel("Total GST");
		lblGst.setForeground(new Color(255, 255, 255));
		lblGst.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblGst.setBackground(Color.WHITE);
		panel_4.add(lblGst);
		
		this.tdis = new JLabel("$0");
		tdis.setBackground(new Color(0, 255, 255));
		tdis.setForeground(new Color(255, 255, 255));
		tdis.setFont(new Font("Tahoma", Font.PLAIN, 30));
		tdis.setBounds(818, 239, 124, 73);
		add(this.tdis);
		
		JPanel panel_5 = new JPanel();
		panel_5.setForeground(new Color(0, 0, 0));
		panel_5.setBackground(new Color(199, 21, 133));
		panel_5.setBounds(779, 212, 163, 100);
		add(panel_5);
		
		JLabel lblDiscounts = new JLabel("Discounts");
		lblDiscounts.setForeground(new Color(255, 255, 255));
		lblDiscounts.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblDiscounts.setBackground(Color.WHITE);
		panel_5.add(lblDiscounts);
		
		this.tquan = new JLabel("0");
		tquan.setBackground(new Color(0, 255, 255));
		tquan.setForeground(new Color(255, 255, 255));
		tquan.setFont(new Font("Tahoma", Font.PLAIN, 30));
		tquan.setBounds(986, 239, 70, 73);
		add(this.tquan);
		
		JPanel panel_6 = new JPanel();
		panel_6.setForeground(new Color(0, 0, 0));
		panel_6.setBackground(new Color(199, 21, 133));
		panel_6.setBounds(958, 212, 118, 100);
		add(panel_6);
		
		JLabel lblQuantitySold = new JLabel("Quantity Sold");
		lblQuantitySold.setForeground(new Color(255, 255, 255));
		lblQuantitySold.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblQuantitySold.setBackground(Color.WHITE);
		panel_6.add(lblQuantitySold);
		
		this.tor = new JLabel("0");
		tor.setBackground(new Color(0, 255, 255));
		tor.setForeground(new Color(255, 255, 255));
		tor.setFont(new Font("Tahoma", Font.PLAIN, 30));
		tor.setBounds(91, 239, 53, 73);
		add(this.tor);
		
		JPanel panel_7 = new JPanel();
		panel_7.setForeground(new Color(0, 0, 0));
		panel_7.setBackground(new Color(199, 21, 133));
		panel_7.setBounds(56, 212, 118, 100);
		add(panel_7);
		
		JLabel lblOrders = new JLabel("All Orders");
		lblOrders.setForeground(new Color(255, 255, 255));
		lblOrders.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblOrders.setBackground(Color.WHITE);
		panel_7.add(lblOrders);
		
		
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(39, 364, 1037, 288);
		add(tabbedPane);
		
		JPanel panel_8 = new JPanel();
		panel_8.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("Table", null, panel_8, null);
		
		this.panel_9 = new JPanel();
		panel_9.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("Graph", null, panel_9, null);
	    panel_9.setLayout(null);
	    
		panel_8.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 0, 1032, 266);
		panel_8.add(scrollPane);
		
		this.table = new JTable(model);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				main.showMViewOrders(user);
			}
		});
		Object[] columns = {"Date", "Orders Recorded", "Total Sales", "Net Sales",  "GST", "Discounts", "Total Items Sold"};
		this.model = new DefaultTableModel();
		model.setColumnIdentifiers(columns);
		scrollPane.setViewportView(table);
		table.setAutoCreateRowSorter(true);
		
	    
	    JComboBox comboBox = new JComboBox();
	    comboBox.setBackground(new Color(255, 255, 255));
	    comboBox.setFont(new Font("Tahoma", Font.PLAIN, 18));
	    comboBox.setModel(new DefaultComboBoxModel(new String[] {"Day","Date", "Month", "Year"}));
	    comboBox.setBounds(133, 325, 140, 26);
	    add(comboBox);
	    
	    JLabel lblSortBy = new JLabel("Sort by:");
	    lblSortBy.setFont(new Font("Tahoma", Font.PLAIN, 20));
	    lblSortBy.setBounds(48, 325, 89, 26);
	    add(lblSortBy);
	    
	    JButton btnSort = new JButton("Sort");
	    btnSort.setBackground(new Color(255, 255, 255));
	    btnSort.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		if(comboBox.getSelectedItem().equals("Date")){
	    			populateJTableDate();
	    			populateGraphDate();
	    		}
	    		else if(comboBox.getSelectedItem().equals("Month")){
	    			populateJTableMonth();
	    			populateGraphMonth();
 
	    		}
	    		else if(comboBox.getSelectedItem().equals("Day")){
	    			populateJTableDay();
	    			populateGraphDate();
	    		}
	    		else{
	    			populateJTableYear();
	    			populateGraphYear();
	    		}
	    	}
	    });
	    btnSort.setFont(new Font("Tahoma", Font.PLAIN, 15));
	    btnSort.setBounds(285, 322, 71, 35);
	    add(btnSort);
	    
	    JLabel lblDailySales = new JLabel("Today's Sales");
	    lblDailySales.setFont(new Font("Tahoma", Font.BOLD, 20));
	    lblDailySales.setBounds(55, 173, 147, 26);
	    add(lblDailySales);
	    
		setCurrDateTime();
		setSaleLabels();
		populateJTableDay();
		populateGraphDate();
		
	}
	private DecimalFormat decfor1 = new DecimalFormat("0");//0dp format
	private DecimalFormat decfor = new DecimalFormat("0.00");//2dp format
	private Map<String, List<Double>> sales2;
	private Map<Integer, List<Double>> sales3;
	
	public void populateJTableDay(){
		
		model.setRowCount(0); 
		Object[] columns = {"Date", "Time", "Order No.", "Total Sales", "Net Sales",  "GST", "Discounts", "Total Items Sold"};
		model.setColumnIdentifiers(columns);
		this.orders = this.main.getController().getAllOrderDetails();
		Object[] row = new Object[8];
		for(int i=0; i<orders.length;i++){
			OrderDetail odd = orders[i];
			row[0] = odd.getDate();
			row[1] = odd.getTime();
			row[2] = odd.getOrderNo();
			row[3] = odd.getTotalOrderPrice();
			row[4] = odd.getSubTotalPrice();
			row[5] = odd.getTotalSavings();
			row[6] = odd.getGst();
			row[7] = odd.getTotalQuantity();
			model.addRow(row);
		}
		
		this.table.setModel(model);
	}

	
	public void populateJTableDate(){
			
			model.setRowCount(0); 
			Object[] columns = {"Date", "Orders Recorded", "Total Sales", "Net Sales",  "GST", "Discounts", "Total Items Sold"};
			model.setColumnIdentifiers(columns);
			this.sales = this.main.getController().calcSalesByDates();
			Object[] row = new Object[7];
			for(String date: sales.keySet()){
				List<Double> objectList = sales.get(date);
				row[0] = date;
				row[1] = decfor1.format(objectList.get(5));
				row[2] = decfor.format(objectList.get(0));
				row[3] = decfor.format(objectList.get(1));
				row[4] = decfor.format(objectList.get(3));
				row[5] = decfor.format(objectList.get(2));
				row[6] = decfor1.format(objectList.get(4));
				model.addRow(row);
			}
			
			this.table.setModel(model);
		}
	
	public void populateJTableMonth(){
		
		model.setRowCount(0); 
		Object[] columns = {"Date", "Orders Recorded", "Total Sales", "Net Sales",  "GST", "Discounts", "Total Items Sold"};
		model.setColumnIdentifiers(columns);
		this.sales2 = this.main.getController().calcSalesByMonth();
		Object[] row = new Object[7];
		for(String month: sales2.keySet()){
			List<Double> objectList = sales2.get(month);
			row[0] = month;
			row[1] = decfor1.format(objectList.get(5));
			row[2] = decfor.format(objectList.get(0));
			row[3] = decfor.format(objectList.get(1));
			row[4] = decfor.format(objectList.get(3));
			row[5] = decfor.format(objectList.get(2));
			row[6] = decfor1.format(objectList.get(4));
			model.addRow(row);
		}
		
		this.table.setModel(model);
	}
	
	public void populateJTableYear(){
		
		model.setRowCount(0); 
		Object[] columns = {"Date", "Orders Recorded", "Total Sales", "Net Sales",  "GST", "Discounts", "Total Items Sold"};
		model.setColumnIdentifiers(columns);
		this.sales3 = this.main.getController().calcSalesByYear();
		Object[] row = new Object[7];
		for(Integer year: sales3.keySet()){
			List<Double> objectList = sales3.get(year);
			row[0] = year;
			row[1] = decfor1.format(objectList.get(5));
			row[2] = decfor.format(objectList.get(0));
			row[3] = decfor.format(objectList.get(1));
			row[4] = decfor.format(objectList.get(3));
			row[5] = decfor.format(objectList.get(2));
			row[6] = decfor1.format(objectList.get(4));
			model.addRow(row);
		}
		
		this.table.setModel(model);
	}

	private void setCurrDateTime(){
		DateTimeFormatter datef = DateTimeFormatter.ofPattern("dd-MMM-yy");
		DateTimeFormatter timef = DateTimeFormatter.ofPattern("HH:mm:ss");
		ld = LocalDate.now();
		LocalTime lt = LocalTime.now();
		lblDate.setText(ld.format(datef));
		lblTime.setText(lt.format(timef));	
	}
	
	public void setSaleLabels(){
		this.sales = this.main.getController().calcSalesByDates();
		if(sales.containsKey(lblDate.getText())){
	            List<Double> objectList = sales.get(lblDate.getText());
	           // for (Double obj : objectList) {
	            	this.tor.setText(""+decfor1.format(objectList.get(5)));
	            	this.tquan.setText(""+decfor1.format(objectList.get(4)));
	            	this.ttax.setText("$"+decfor.format(objectList.get(3)));
	            	this.tdis.setText("$" + decfor.format(objectList.get(2)));
	            	this.tnet.setText("$"+decfor.format(objectList.get(1)));
	            	this.lbltsale.setText("$" +decfor.format(objectList.get(0)));
	           // }
		}else{
			JOptionPane.showMessageDialog(null, "No orders made today.");
		}
	}
	
	public void populateGraphDate(){
		// Remove the current chart from panel_9
        panel_9.removeAll();
        panel_9.revalidate();
        panel_9.repaint();

	    TimeSeries series = new TimeSeries("Total Sales");
		this.sales = this.main.getController().calcSalesByDates();
		for(String date: sales.keySet()){
			List<Double> objectList = sales.get(date);
			
			 SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy");
		        try {
		            Date date2 = sdf.parse(date);
		            series.addOrUpdate(new org.jfree.data.time.Day(date2), objectList.get(0));
		        } catch (ParseException e) {
		            e.printStackTrace();
		        }	
		}
		
	    TimeSeriesCollection dataset = new TimeSeriesCollection(series);

	    JFreeChart chart = ChartFactory.createTimeSeriesChart(
	        "Total Sales Per Date", // Chart title
	        "Date",                   // X-axis label
	        "Total Sales",            // Y-axis label
	        dataset,                  // Dataset
	        true,                     // Include legend
	        true,                     // Tooltips
	        false                     // URLs
	    );

	    XYPlot plot = chart.getXYPlot();
	    DateAxis axis = (DateAxis) plot.getDomainAxis();
	    axis.setDateFormatOverride(new SimpleDateFormat("dd-MMM-yy"));
	    
	    XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();

	    // Set the line color for the series
        renderer.setSeriesPaint(0, Color.BLUE);

        // Set the shape for the series data points
        renderer.setSeriesShape(0, new Ellipse2D.Double(-3, -3, 6, 6));
     
        // Set the background color of the plot
        plot.setBackgroundPaint(new Color(240, 240, 240)); // Light gray color
        // Set the domain (X-axis) grid line color
        plot.setDomainGridlinePaint(Color.GRAY); // Set the color to desired dark color
        // Set the range (Y-axis) grid line color
        plot.setRangeGridlinePaint(Color.GRAY); // Set the color to desired dark color
        plot.setRenderer(renderer);
        
	    ChartPanel chartPanel = new ChartPanel(chart);
	    chartPanel.setBackground(Color.WHITE);
	    chartPanel.setForeground(Color.WHITE);
	    chartPanel.setBounds(12, 0, 1008, 258);
	    
		chartPanel.setPreferredSize(panel_9.getSize()); // Set preferred size
	    this.panel_9.add(chartPanel);
	    // Refresh the panel to show the new chart
        panel_9.validate();
        panel_9.repaint();
	}
	
	public void populateGraphMonth(){
		// Remove the current chart from panel_9
        panel_9.removeAll();
        panel_9.revalidate();
        panel_9.repaint();
		
		this.sales2 = this.main.getController().calcSalesByMonth();

	    // Create a dataset for the sales graph
	    DefaultCategoryDataset dataset = new DefaultCategoryDataset();

	    // Populate the dataset with sales data from orderDList
	    for (String month: sales2.keySet()) {
	    	List<Double> objectList = sales2.get(month);
	        dataset.addValue(objectList.get(0), "Total Sales", month);
	    }

	 // Create the line chart
	    JFreeChart chart2 = ChartFactory.createLineChart(
	            "Total Sales per Month",
	            "Month",
	            "Total Sales",
	            dataset,
	            PlotOrientation.VERTICAL,
	            true,
	            true,
	            false
	    );

	    CategoryPlot plot2 = chart2.getCategoryPlot();
	    LineAndShapeRenderer renderer2 = new LineAndShapeRenderer();
	    plot2.setRenderer(renderer2);

	    // Set the color for the line
	    renderer2.setSeriesPaint(0, Color.BLUE); // Change to the desired color

	    plot2.setBackgroundPaint(new Color(240, 240, 240)); // Light gray color
	    plot2.setDomainGridlinePaint(Color.GRAY); // X-axis gridline color
	    plot2.setDomainGridlinesVisible(true);
	    plot2.setRangeGridlinePaint(Color.GRAY);  // Y-axis gridline color

	    ChartPanel chartPanel2 = new ChartPanel(chart2);
	    chartPanel2.setBackground(Color.WHITE);
	    chartPanel2.setForeground(Color.WHITE);
	    chartPanel2.setBounds(12, 0, 1008, 258);
	    
		chartPanel2.setPreferredSize(panel_9.getSize()); // Set preferred size
	    this.panel_9.add(chartPanel2);
	    
	    // Refresh the panel to show the new chart
	    panel_9.validate();
	    panel_9.repaint();
	}
	
	public void populateGraphYear(){
		// Remove the current chart from panel_9
        panel_9.removeAll();
        panel_9.revalidate();
        panel_9.repaint();

		this.sales3 = this.main.getController().calcSalesByYear();

	    // Create a dataset for the sales graph
	    DefaultCategoryDataset dataset = new DefaultCategoryDataset();

	    // Populate the dataset with sales data from orderDList
	    for (Integer year: sales3.keySet()) {
	    	List<Double> objectList = sales3.get(year);
	        dataset.addValue(objectList.get(0), "Total Sales", year);
	    }

		 // Create the line chart
	    JFreeChart chart3 = ChartFactory.createLineChart(
	            "Total Sales per Year",
	            "Year",
	            "Total Sales",
	            dataset,
	            PlotOrientation.VERTICAL,
	            true,
	            true,
	            false
	    );
	    
	    CategoryPlot plot3 = chart3.getCategoryPlot();
	    LineAndShapeRenderer renderer3 = new LineAndShapeRenderer();
	    plot3.setRenderer(renderer3);

	    // Set the color for the line
	    renderer3.setSeriesPaint(0, Color.BLUE); // Change to the desired color

	    plot3.setBackgroundPaint(new Color(240, 240, 240)); // Light gray color
	    plot3.setDomainGridlinePaint(Color.GRAY); // X-axis gridline color
	    plot3.setDomainGridlinesVisible(true);
	    plot3.setRangeGridlinePaint(Color.GRAY);  // Y-axis gridline color

	    ChartPanel chartPanel3 = new ChartPanel(chart3);
	    chartPanel3.setBackground(Color.WHITE);
	    chartPanel3.setForeground(Color.WHITE);
	    chartPanel3.setBounds(12, 0, 1008, 258);
	    
		chartPanel3.setPreferredSize(panel_9.getSize()); // Set preferred size
	    this.panel_9.add(chartPanel3);
	    
	    // Refresh the panel to show the new chart
        panel_9.validate();
        panel_9.repaint();
	}
	
}