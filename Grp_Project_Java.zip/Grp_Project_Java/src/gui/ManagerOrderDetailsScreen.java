package gui;

import javax.swing.JPanel;

import controller.MainFrame;
import data.OrderDetail;
import data.OrderItem;
import data.User;

import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JDesktopPane;

public class ManagerOrderDetailsScreen extends JPanel{
	private MainFrame main;
	private JTable table;
	private JLabel lblNumItems;
	private OrderItem[] OrderItem;
	private JList list;
	private int i;
	private JScrollPane scrollPane;
	private Container con ;
	private OrderItem[] oi ;
	private JPanel panel_2;
	private JTable table_1;
	private DefaultTableModel model;
	private OrderItem[] orderItems;
	private User user;
	public ManagerOrderDetailsScreen(MainFrame main, User user1, int i) {
		this.main = main;
		this.user = user1;
		this.i = i;
		setLayout(null);
		this.setSize(1120, 665);
		
		OrderDetail od = main.getController().getOrderDetail(i);
		DecimalFormat decfor = new DecimalFormat("0.00");
		setBackground(new Color(255, 240, 245));
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(221, 160, 221));
		panel.setBounds(0, 0, 1120, 94);
		add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMDashboard(user1);
			}
		});
		lblNewLabel.setBounds(24, 18, 69, 62);
		Image img = new ImageIcon(this.getClass().getResource("/loginiconn.png")).getImage().getScaledInstance(lblNewLabel.getWidth(), lblNewLabel.getHeight(), Image.SCALE_SMOOTH);
		lblNewLabel.setIcon(new ImageIcon(img));	
		panel.add(lblNewLabel);
		
		JLabel lblGrocerySalesSystem = new JLabel("Joy Minimart");
		lblGrocerySalesSystem.setForeground(new Color(139, 0, 139));
		lblGrocerySalesSystem.setFont(new Font("Segoe UI Semilight", Font.BOLD, 50));
		lblGrocerySalesSystem.setBounds(386, 13, 355, 67);
		panel.add(lblGrocerySalesSystem);
		
		JLabel label = new JLabel("");
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showLogin();
			}
			
		});
		label.setBounds(1054, 29, 54, 42);
		Image img1 = new ImageIcon(this.getClass().getResource("/logout.png")).getImage().getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_SMOOTH);
		label.setIcon(new ImageIcon(img1));
		panel.add(label);
		
		JLabel label_2 = new JLabel(user1.getStaffName());
		label_2.setBounds(922, 29, 104, 42);
		panel.add(label_2);
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		JLabel lblWelcome = new JLabel("Welcome,");
		lblWelcome.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblWelcome.setBounds(833, 38, 77, 26);
		panel.add(lblWelcome);
		
		JPanel panel_1 = new JPanel();
		panel_1.setForeground(new Color(255, 204, 255));
		panel_1.setBackground(new Color(224, 255, 255));
		panel_1.setBounds(0, 121, 1120, 50);
		add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblItemDetails = new JLabel("Order Details");
		lblItemDetails.setForeground(new Color(0, 0, 0));
		lblItemDetails.setBounds(463, 0, 172, 50);
		panel_1.add(lblItemDetails);
		lblItemDetails.setFont(new Font("Tahoma", Font.BOLD, 25));
		
		JLabel lblHome = new JLabel("Home");
		lblHome.setForeground(new Color(0, 0, 0));

		lblHome.setBackground(new Color(240, 255, 255));
		lblHome.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				main.showMDashboard(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblHome.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblHome.setForeground(new Color(0, 0, 0));
			}
		});
		lblHome.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblHome.setBounds(10, 92, 56, 26);
		add(lblHome);
		
		JLabel lblCreateItems = new JLabel("Create Items");
		lblCreateItems.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMCreateScreen(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblCreateItems.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblCreateItems.setForeground(new Color(0, 0, 0));
			}
			
		});
		lblCreateItems.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblCreateItems.setBounds(86, 92, 116, 26);
		add(lblCreateItems);
		
		JLabel lblViewItems = new JLabel("View Items");
		lblViewItems.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMViewItems(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblViewItems.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblViewItems.setForeground(new Color(0, 0, 0));
			}
		});
		lblViewItems.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblViewItems.setBounds(229, 92, 109, 26);
		add(lblViewItems);
		
		JLabel lblViewSaleSummary = new JLabel("View Sale Summary");
		lblViewSaleSummary.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMSaleSummary(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblViewSaleSummary.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblViewSaleSummary.setForeground(new Color(0, 0, 0));
			}
		});
		lblViewSaleSummary.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblViewSaleSummary.setBounds(360, 92, 195, 26);
		add(lblViewSaleSummary);
		
		JLabel lblTrackInventory = new JLabel("Track Inventory");
		lblTrackInventory.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMInventory(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblTrackInventory.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblTrackInventory.setForeground(new Color(0, 0, 0));
			}
		});
		lblTrackInventory.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTrackInventory.setBounds(567, 92, 140, 26);
		add(lblTrackInventory);
		
		JLabel lblViewOrders = new JLabel("View Orders");
		lblViewOrders.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMViewOrders(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblViewOrders.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblViewOrders.setForeground(new Color(0, 0, 0));
			}
		});
		lblViewOrders.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblViewOrders.setBounds(733, 92, 116, 26);
		add(lblViewOrders);
		
		JLabel lblDiscountItems = new JLabel("Discount");
		lblDiscountItems.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMDiscount(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblDiscountItems.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblDiscountItems.setForeground(new Color(0, 0, 0));
			}
		});
		lblDiscountItems.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblDiscountItems.setBounds(871, 92, 109, 26);
		add(lblDiscountItems);
		
		JLabel lblChangeRole = new JLabel("Change Role");
		lblChangeRole.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showStaffMenuScreen(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblChangeRole.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblChangeRole.setForeground(new Color(0, 0, 0));
			}
		});
		lblChangeRole.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblChangeRole.setBounds(979, 92, 129, 26);
		add(lblChangeRole);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBounds(0, 93, 1120, 35);
		add(panel_4);
		panel_4.setBackground(new Color(255, 204, 255));
		
		JLabel lblStaffName = new JLabel("Staff Name:");
		lblStaffName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblStaffName.setBounds(12, 234, 115, 23);
		add(lblStaffName);
		
		JLabel lblForName = new JLabel(od.getStaffName()); 
		lblForName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblForName.setBounds(152, 234, 169, 23);
		add(lblForName);
		
		JLabel lblDate = new JLabel("Date:");
		lblDate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblDate.setBounds(12, 280, 115, 23);
		add(lblDate);
		
		JLabel lblForDate = new JLabel(od.getDate());
		lblForDate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblForDate.setBounds(152, 280, 158, 22);
		add(lblForDate);
		
		JLabel lblOrderNum = new JLabel("Order Number:");
		lblOrderNum.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblOrderNum.setBounds(12, 189, 139, 23);
		add(lblOrderNum);
		
		JLabel lblForOrderNum = new JLabel(String.valueOf(od.getOrderNo()));
		lblForOrderNum.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblForOrderNum.setBounds(152, 189, 129, 23);
		add(lblForOrderNum);
		
		JLabel labelx = new JLabel("-------------------------------------------------------------------------------------");
		labelx.setBounds(12, 316, 440, 16);
		add(labelx);
		
		 this.panel_2= new JPanel();
		 panel_2.setBackground(new Color(255, 255, 255));
		panel_2.setBounds(450, 212, 658, 440);
		panel_2.setBorder(new LineBorder(new Color(0,0,0),5));
		add(panel_2);
		panel_2.setLayout(null);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(12, 13, 634, 418);
		panel_2.add(scrollPane_1);
		
		table_1 = new JTable();
		scrollPane_1.setViewportView(table_1);
		
		Object[] columns = {
				"Name", "Quantity", "Price per item", "Discount per item"
			};
		this.model = new DefaultTableModel(0,4);
		this.model.setColumnIdentifiers(columns);
		
		JLabel lblDescription = new JLabel("Description");
		lblDescription.setFont(new Font("Segoe UI Historic", Font.BOLD, 25));
		lblDescription.setBounds(472, 176, 158, 36);
		add(lblDescription);
		
		JLabel lblAmount = new JLabel("Amount");
		lblAmount.setFont(new Font("Segoe UI Historic", Font.BOLD, 25));
		lblAmount.setBounds(788, 176, 105, 36);
		add(lblAmount);
		
		JLabel lblDiscount = new JLabel("Discount");
		lblDiscount.setFont(new Font("Segoe UI Historic", Font.BOLD, 25));
		lblDiscount.setBounds(922, 178, 115, 32);
		add(lblDiscount);
		
		JLabel lblQuantity = new JLabel("Quantity");
		lblQuantity.setFont(new Font("Segoe UI Historic", Font.BOLD, 25));
		lblQuantity.setBounds(642, 178, 115, 32);
		add(lblQuantity);
		
		JLabel lblTotal = new JLabel("Total $");
		lblTotal.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTotal.setBounds(12, 346, 115, 32);
		add(lblTotal);
		
		JLabel lblForTotalP = new JLabel(decfor.format(od.getTotalOrderPrice()));
		lblForTotalP.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblForTotalP.setBounds(265, 342, 139, 36);
		add(lblForTotalP);
		
		JLabel lblSubTotal = new JLabel("Sub Total $");
		lblSubTotal.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblSubTotal.setBounds(12, 391, 139, 32);
		add(lblSubTotal);
		
		JLabel lblGst = new JLabel("GST (8%)");
		lblGst.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblGst.setBounds(12, 436, 139, 32);
		add(lblGst);
		
		JLabel lblForSubTotal = new JLabel(decfor.format(od.getSubTotalPrice()));
		lblForSubTotal.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblForSubTotal.setBounds(265, 389, 139, 36);
		add(lblForSubTotal);
		
		JLabel lblForGST = new JLabel(decfor.format(od.getGst()));
		lblForGST.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblForGST.setBounds(265, 434, 139, 36);
		add(lblForGST);
		
		lblNumItems = new JLabel("Number of Items:");
		lblNumItems.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNumItems.setBounds(12, 526, 169, 32);
		add(lblNumItems);
		
		JLabel lblForNumItems = new JLabel(String.valueOf(od.getTotalItems()));
		lblForNumItems.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblForNumItems.setBounds(265, 522, 139, 36);
		add(lblForNumItems);
		
		JLabel lblTotalQuantity = new JLabel("Total Quantity:");
		lblTotalQuantity.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTotalQuantity.setBounds(12, 571, 158, 32);
		add(lblTotalQuantity);
		
		JLabel lblTotalQ = new JLabel(String.valueOf(od.getTotalQuantity()));
		lblTotalQ.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTotalQ.setBounds(265, 571, 139, 36);
		add(lblTotalQ);
		
		JLabel lblTotalSavings = new JLabel("Total Savings:");
		lblTotalSavings.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTotalSavings.setBounds(12, 481, 158, 32);
		add(lblTotalSavings);
		
		JLabel lblForTotalS = new JLabel(decfor.format(od.getTotalSavings()));
		lblForTotalS.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblForTotalS.setBounds(265, 483, 139, 36);
		add(lblForTotalS);
		
		JLabel lblForTime = new JLabel(od.getTime());
		lblForTime.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblForTime.setBounds(307, 280, 119, 23);
		add(lblForTime);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				main.showMViewOrders(user1);
			}
		});
		btnNewButton.setBounds(12, 616, 139, 36);
		add(btnNewButton);
		
		addOrderItems(i);
	}
	private void addOrderItems(int i){
		this.model.setRowCount(0);

		this.orderItems = this.main.getController().getAllOrderItems(this.i);
		Object[] row = new Object[4];
		DecimalFormat decfor = new DecimalFormat("0.00");
		for(int e = 0; e < this.orderItems.length; e++){
			OrderItem op = this.orderItems[e];
			row[0] = op.getName();
			row[1] = op.getQuantity();
			row[2] = decfor.format(op.getPrice());
			row[3] = decfor.format(op.getDiscount());
			
			System.out.println("row[0]"+row[0]);
			System.out.println(row[1]);
			System.out.println(row[2]);
			System.out.println(row[3]);
			
			this.model.addRow(row);
			
		}
		table_1.setModel(model);
		
	}
		
}
