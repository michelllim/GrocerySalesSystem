package gui;

import javax.swing.JPanel;

import controller.MainFrame;
import data.Item;
import data.OrderDetail;
import data.OrderItem;
import data.User;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import java.awt.Component;
import javax.swing.JTable;

public class StaffMenuScreen extends JPanel {
	private MainFrame main;
	private DefaultTableModel model;
	private User user;
	private JTable table;
	private OrderDetail[] od;

	public StaffMenuScreen(MainFrame main, User user){
		this.main = main;
		this.user = user;
		
		setLayout(null);
		this.setSize(1120, 665);
		
		setBackground(new Color(255, 250, 240));
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(224, 255, 255));
		panel.setBounds(0, 0, 1120, 94);
		add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.out.println("user.getRole() "+ user.getRole());
			if(user.getRole() == "Manager"){
				main.showMDashboard(user);
			}
			}
		});		
		lblNewLabel.setBounds(24, 18, 69, 62);
		Image img = new ImageIcon(this.getClass().getResource("/loginiconn.png")).getImage().getScaledInstance(lblNewLabel.getWidth(), lblNewLabel.getHeight(), Image.SCALE_SMOOTH);
		lblNewLabel.setIcon(new ImageIcon(img));	
		panel.add(lblNewLabel);
		
		JLabel lblGrocerySalesSystem = new JLabel("Joy Minimart");
		lblGrocerySalesSystem.setForeground(new Color(0, 0, 0));
		lblGrocerySalesSystem.setFont(new Font("Segoe UI Semilight", Font.BOLD, 50));
		lblGrocerySalesSystem.setBounds(386, 13, 355, 67);
		panel.add(lblGrocerySalesSystem);
		
		JLabel label = new JLabel("");
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showLogin();
			}
			
		});
		label.setBounds(1054, 29, 54, 42);
		Image img1 = new ImageIcon(this.getClass().getResource("/logout.png")).getImage().getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_SMOOTH);
		label.setIcon(new ImageIcon(img1));
		panel.add(label);
		
		JLabel label_2 = new JLabel(user.getStaffName());
		label_2.setBounds(922, 29, 104, 42);
		panel.add(label_2);
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		JLabel lblWelcome = new JLabel("Welcome,");
		lblWelcome.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblWelcome.setBounds(833, 38, 77, 26);
		panel.add(lblWelcome);
		
		JPanel panel_1 = new JPanel();
		panel_1.setForeground(new Color(255, 204, 255));
		panel_1.setBackground(new Color(255, 215, 0));
		panel_1.setBounds(0, 94, 1120, 50);
		add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblItemDetails = new JLabel("Home");
		lblItemDetails.setForeground(new Color(0, 0, 0));
		lblItemDetails.setBounds(496, 0, 172, 50);
		panel_1.add(lblItemDetails);
		lblItemDetails.setFont(new Font("Tahoma", Font.BOLD, 25));
		
		JButton btnCreateOrder = new JButton("Create");
		btnCreateOrder.setBackground(new Color(255, 255, 255));
		btnCreateOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				main.getController().createOrder();
				int index = main.getController().getOrderListSize();
				main.showCreateOrderScreen(index,user);

			}
		});
		btnCreateOrder.setFont(new Font("Dialog", Font.PLAIN, 40));
		btnCreateOrder.setBounds(698, 287, 369, 77);
		add(btnCreateOrder);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(63, 259, 611, 353);
		add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		Object[] columns = {
				"Order No.", "Date", "Time","Total Price","Total Quantity"
			};
		this.model = new DefaultTableModel(0,5);
		this.model.setColumnIdentifiers(columns);
		
		scrollPane.setViewportView(table);
		populateTable();
		
		JButton btnEdit = new JButton("Edit");
		btnEdit.setBackground(new Color(255, 255, 255));
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				try{
					int index = table.getSelectedRow();
					main.showCreateOrderScreen(index+1,user);
				}
				catch(ArrayIndexOutOfBoundsException e){
					JOptionPane.showMessageDialog(null, "There are no orders to be edited. Please create an order.", "Order System", JOptionPane.OK_OPTION);
				}
				catch(NullPointerException a){
					JOptionPane.showMessageDialog(null, "Please select the order to edit", "Order System", JOptionPane.OK_OPTION);
				}
			}
		});
		btnEdit.setFont(new Font("Tahoma", Font.PLAIN, 40));
		btnEdit.setBounds(698, 391, 369, 77);
		add(btnEdit);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try{
					int index = table.getSelectedRow();
					main.getController().deleteOrder(index);
					populateTable();
				}
				catch(ArrayIndexOutOfBoundsException g){
					JOptionPane.showMessageDialog(null, "There are no orders to be delete. Please create an order.", "Order System", JOptionPane.OK_OPTION);
				}
				catch(NullPointerException j){
					JOptionPane.showMessageDialog(null, "Please select the order to delete", "Order System", JOptionPane.OK_OPTION);
				}
			

			}
		});
		btnDelete.setBackground(new Color(255, 255, 255));
		btnDelete.setFont(new Font("Tahoma", Font.PLAIN, 40));
		btnDelete.setBounds(698, 506, 369, 77);
		add(btnDelete);
		
		JLabel lblPastOrders = new JLabel("Past Orders :");
		lblPastOrders.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblPastOrders.setBounds(84, 208, 187, 40);
		add(lblPastOrders);
		
		this.populateTable();
	}

	private void populateTable(){
		this.model.setRowCount(0);
		od = main.getController().getAllOrderDetails();
		
		for(int i=0;i<od.length;i++){
			DecimalFormat decfor = new DecimalFormat("0.00");
			Object[] row = new Object[5];
			OrderDetail op = od[i];
			row[0] = i+1;
			row[1] = op.getDate();
			row[2] = op.getTime();
			row[3] = decfor.format(op.getTotalOrderPrice());
			row[4] = op.getTotalQuantity();
			System.out.println("row[0]"+row[0]);
			System.out.println(row[1]);
			System.out.println(row[2]);
			System.out.println(row[3]);
		
			this.model.addRow(row);
			
		}
		this.table.setModel(this.model);
		

	}
}