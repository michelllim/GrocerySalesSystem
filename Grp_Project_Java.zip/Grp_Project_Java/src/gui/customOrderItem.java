package gui;

import javax.swing.JPanel;

import data.OrderItem;
import javax.swing.JLabel;
import java.awt.Color;

public class customOrderItem extends JPanel{
	public customOrderItem(OrderItem i) {
		setBackground(Color.GREEN);
		this.setSize(634, 144);
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel(i.getName());
		lblNewLabel.setBounds(280, 52, 126, 35);
		add(lblNewLabel);
		System.out.println("end of code in custom");
	}

}
