package gui;

import javax.swing.JPanel;

import controller.MainFrame;
import data.OrderDetail;
import data.User;

import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;

import com.toedter.calendar.JDateChooser;
import javax.swing.JTextField;

public class ManagerViewOrders extends JPanel{
	private MainFrame main;
	private JTable table;
 	private DefaultTableModel model;
	private OrderDetail[] OrderDetail ;
	private JLayeredPane layeredPane;
	private JPanel panelName;
	private JPanel panelDate;
	private JTextField textField;
	private JComboBox comboBox ;
	private JDateChooser dateChooser;
	private TableRowSorter sorter;
	private OrderDetail[] od;
	private OrderDetail[] od2;
	
	public ManagerViewOrders(MainFrame main, User user1){
		this.main = main;
		setLayout(null);
		this.setSize(1120, 665);
		
		setBackground(new Color(255, 240, 245));
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(221, 160, 221));
		panel.setBounds(0, 0, 1120, 94);
		add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMDashboard(user1);
			}
		});
		lblNewLabel.setBounds(24, 18, 69, 62);
		Image img = new ImageIcon(this.getClass().getResource("/loginiconn.png")).getImage().getScaledInstance(lblNewLabel.getWidth(), lblNewLabel.getHeight(), Image.SCALE_SMOOTH);
		lblNewLabel.setIcon(new ImageIcon(img));	
		panel.add(lblNewLabel);
		
		JLabel lblGrocerySalesSystem = new JLabel("Joy Minimart");
		lblGrocerySalesSystem.setForeground(new Color(139, 0, 139));
		lblGrocerySalesSystem.setFont(new Font("Segoe UI Semilight", Font.BOLD, 50));
		lblGrocerySalesSystem.setBounds(386, 13, 355, 67);
		panel.add(lblGrocerySalesSystem);
		
		JLabel label = new JLabel("");
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showLogin();
			}
			
		});
		label.setBounds(1054, 29, 54, 42);
		Image img1 = new ImageIcon(this.getClass().getResource("/logout.png")).getImage().getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_SMOOTH);
		label.setIcon(new ImageIcon(img1));
		panel.add(label);
		
		JLabel label_2 = new JLabel(user1.getStaffName());
		label_2.setBounds(922, 29, 104, 42);
		panel.add(label_2);
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		JLabel lblWelcome = new JLabel("Welcome,");
		lblWelcome.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblWelcome.setBounds(833, 38, 77, 26);
		panel.add(lblWelcome);
		
		JPanel panel_1 = new JPanel();
		panel_1.setForeground(new Color(255, 204, 255));
		panel_1.setBackground(new Color(224, 255, 255));
		panel_1.setBounds(0, 121, 1120, 50);
		add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblItemDetails = new JLabel("View Orders");
		lblItemDetails.setForeground(new Color(0, 0, 0));
		lblItemDetails.setBounds(455, 0, 172, 50);
		panel_1.add(lblItemDetails);
		lblItemDetails.setFont(new Font("Tahoma", Font.BOLD, 24));
		
		JLabel lblHome = new JLabel("Home");
		lblHome.setForeground(new Color(0, 0, 0));

		lblHome.setBackground(new Color(240, 255, 255));
		lblHome.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				main.showMDashboard(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblHome.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblHome.setForeground(new Color(0, 0, 0));
			}
		});
		lblHome.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblHome.setBounds(10, 92, 56, 26);
		add(lblHome);
		
		JLabel lblCreateItems = new JLabel("Create Items");
		lblCreateItems.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMCreateScreen(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblCreateItems.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblCreateItems.setForeground(new Color(0, 0, 0));
			}
			
		});
		lblCreateItems.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblCreateItems.setBounds(86, 92, 116, 26);
		add(lblCreateItems);
		
		JLabel lblViewItems = new JLabel("View Items");
		lblViewItems.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMViewItems(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblViewItems.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblViewItems.setForeground(new Color(0, 0, 0));
			}
		});
		lblViewItems.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblViewItems.setBounds(229, 92, 109, 26);
		add(lblViewItems);
		
		JLabel lblViewSaleSummary = new JLabel("View Sale Summary");
		lblViewSaleSummary.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMSaleSummary(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblViewSaleSummary.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblViewSaleSummary.setForeground(new Color(0, 0, 0));
			}
		});
		lblViewSaleSummary.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblViewSaleSummary.setBounds(360, 92, 195, 26);
		add(lblViewSaleSummary);
		
		JLabel lblTrackInventory = new JLabel("Track Inventory");
		lblTrackInventory.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMInventory(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblTrackInventory.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblTrackInventory.setForeground(new Color(0, 0, 0));
			}
		});
		lblTrackInventory.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTrackInventory.setBounds(567, 92, 140, 26);
		add(lblTrackInventory);
		
		JLabel lblViewOrders = new JLabel("View Orders");
		lblViewOrders.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMViewOrders(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblViewOrders.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblViewOrders.setForeground(new Color(0, 0, 0));
			}
		});
		lblViewOrders.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblViewOrders.setBounds(733, 92, 116, 26);
		add(lblViewOrders);
		
		JLabel lblDiscountItems = new JLabel("Discount");
		lblDiscountItems.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMDiscount(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblDiscountItems.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblDiscountItems.setForeground(new Color(0, 0, 0));
			}
		});
		lblDiscountItems.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblDiscountItems.setBounds(871, 92, 109, 26);
		add(lblDiscountItems);
		
		JLabel lblChangeRole = new JLabel("Change Role");
		lblChangeRole.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showStaffMenuScreen(user1);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblChangeRole.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblChangeRole.setForeground(new Color(0, 0, 0));
			}
		});
		lblChangeRole.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblChangeRole.setBounds(979, 92, 129, 26);
		add(lblChangeRole);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBounds(0, 93, 1120, 35);
		add(panel_4);
		panel_4.setBackground(new Color(255, 204, 255));
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(53, 235, 1015, 336);
		add(scrollPane);
		
		table = new JTable(model);
		Object[] columns = {
				"Staff Name","Order No.","Date","Time","Total Amount"
			};
		this.model = new DefaultTableModel(0,5);
		this.model.setColumnIdentifiers(columns);
		sorter = new TableRowSorter<DefaultTableModel>(model);
		table.setRowSorter(sorter);
		scrollPane.setViewportView(table);
		
		JLabel lblOrders = new JLabel("Orders");
		lblOrders.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblOrders.setBounds(506, 40, 100, 17);
		add(lblOrders);
		
		JButton btnDetails = new JButton("Details");
		btnDetails.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnDetails.setBackground(new Color(255, 255, 255));
		btnDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int i = table.getSelectedRow();
				int orderNo = Integer.valueOf(table.getValueAt(i, 1).toString());
				main.showMOrderDetails(user1, orderNo);
			}
		});
		btnDetails.setBounds(939, 584, 141, 51);
		add(btnDetails);
		
		JButton btnExportAllOrders = new JButton("Export");
		btnExportAllOrders.setBackground(new Color(255, 255, 255));
		btnExportAllOrders.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnExportAllOrders.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int option = JOptionPane.showConfirmDialog(null, "Confirm export Orders?"); // 0=yes, 1=no, 2=cancel
				if (option == 0){
			    JOptionPane.showMessageDialog(null, "Orders have been exported.", "System Reminder", 1, null);
				main.getController().writecsvOrders();
				}
			}
		});
		btnExportAllOrders.setBounds(231, 584, 147, 50);
		add(btnExportAllOrders);
		
		JButton btnImportAllOrders = new JButton("Import");
		btnImportAllOrders.setBackground(new Color(255, 255, 255));
		btnImportAllOrders.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnImportAllOrders.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				main.getController().setDefaultOrders();
				populateTable();
			}
		});
		btnImportAllOrders.setBounds(48, 584, 147, 50);
		add(btnImportAllOrders);
		
		JLabel lblFilterBy = new JLabel("Filter By:");
		lblFilterBy.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblFilterBy.setBounds(53, 184, 74, 38);
		add(lblFilterBy);
		
		comboBox= new JComboBox();
		comboBox.setBackground(new Color(255, 255, 255));
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String thing = comboBox.getSelectedItem().toString();
				System.out.println(thing);
				showPanelFilter(thing);
			}
		});
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Staff Name", "Date"}));
		comboBox.setBounds(124, 193, 94, 22);
		add(comboBox);
		
		this.layeredPane = new JLayeredPane();
		layeredPane.setBackground(new Color(255, 255, 255));
		layeredPane.setBounds(282, 184, 354, 35);
		add(layeredPane);
		
		JButton btnNewButton = new JButton("Filter");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String thing = comboBox.getSelectedItem().toString();
				if (thing.equals("Staff Name")){
						String name = textField.getText();
						System.out.println(name);
						populateTableByName(name);

				}
				else{
					SimpleDateFormat spf = new SimpleDateFormat("dd-MMM-yy");
					String date = spf.format(dateChooser.getDate());
					populateTableByDate(date);
				}
			}
		});
		btnNewButton.setBounds(664, 184, 109, 38);
		add(btnNewButton);

		
		populateTable();
		//showPanelFilter();
	}
	private void populateTable(){
		OrderDetail = main.getController().getAllOrderDetails();
		Object[] row = new Object[5];
		DecimalFormat decfor = new DecimalFormat("0.00");
		for(int i = 0; i < OrderDetail.length; i++){
			OrderDetail op = OrderDetail[i];
			row[0] = op.getStaffName();
			row[1] = op.getOrderNo();
			row[2] = op.getDate();
			row[3] = op.getTime();
			row[4] = decfor.format(op.getTotalOrderPrice());
			
			System.out.println("row[0]"+row[0]);
			System.out.println(row[1]);
			System.out.println(row[2]);
			System.out.println(row[3]);
			
			model.addRow(row);
			
		}
		this.table.setModel(model);
	}
	private void populateTableByName(String name){
		this.model.setRowCount(0);
		od =  main.getController().getOrdersByName(name);
		System.out.println("length is "+od.length);
		Object[] row = new Object[5];
		DecimalFormat decfor = new DecimalFormat("0.00");
		for(int i = 0; i < od.length; i++){
			OrderDetail op = od[i];
			row[0] = op.getStaffName();
			row[1] = op.getOrderNo();
			row[2] = op.getDate();
			row[3] = op.getTime();
			row[4] = decfor.format(op.getTotalOrderPrice());
			
			System.out.println("row[0]"+row[0]);
			System.out.println(row[1]);
			System.out.println(row[2]);
			System.out.println(row[3]);
			
			model.addRow(row);
			
		}
		this.table.setModel(model);
	}
	private void populateTableByDate(String date){
		this.model.setRowCount(0);
		od2 = main.getController().getOrdersByDate(date);
		System.out.println("length is "+od2.length);
		Object[] row = new Object[5];
		DecimalFormat decfor = new DecimalFormat("0.00");
		for(int i = 0; i < od2.length; i++){
			OrderDetail op = od2[i];
			row[0] = op.getStaffName();
			row[1] = op.getOrderNo();
			row[2] = op.getDate();
			row[3] = op.getTime();
			row[4] = decfor.format(op.getTotalOrderPrice());
			
			System.out.println("row[0]"+row[0]);
			System.out.println(row[1]);
			System.out.println(row[2]);
			System.out.println(row[3]);
			
			model.addRow(row);
			
		}
		this.table.setModel(model);
	}
	private void showPanelFilter(String thing){
		if (thing.equals("Staff Name")){
			layeredPane.removeAll();
			 this.panelName = new JPanel();
				panelName.setBounds(0, 0, 354, 35);
				layeredPane.add(panelName);
				panelName.setFont(new Font("Tahoma", Font.PLAIN, 15));
				panelName.setLayout(null);
				
				textField = new JTextField();
				textField.setFont(new Font("Tahoma", Font.PLAIN, 15));
				textField.setBounds(0, 0, 354, 35);
				panelName.add(textField);
				textField.setColumns(10);
			
		}
		else{
			layeredPane.removeAll();
			this.panelDate = new JPanel();
			panelDate.setBounds(0, 0, 354, 35);
			layeredPane.add(panelDate);
			panelDate.setFont(new Font("Tahoma", Font.PLAIN, 15));
			panelDate.setLayout(null);
			
			dateChooser = new JDateChooser();
			dateChooser.setBounds(0, 0, 354, 35);
			panelDate.add(dateChooser);
		}
	}
	
}