package data;

public class OrderDetail {
	private String date;
	private String time;
	private String staffName;
	private int orderNo;
	private int totalItems;
	private double totalSavings;
	private double totalOrderPrice;
	private int totalQuantity;
	private double gst;
	private double SubTotalPrice;
	
	private int totalItemsSold;
	private double totalDiscounts;
	private double totalSales;
	private int totalOrdersRecorded;
	private double totalTaxes;
	private double totalNetSales;
	
	public int getTotalItemsSold() {
		return totalItemsSold;
	}
	public void setTotalItemsSold(int totalItemsSold) {
		this.totalItemsSold = totalItemsSold;
	}
	public double getTotalDiscounts() {
		return totalDiscounts;
	}
	public void setTotalDiscounts(double totalDiscounts) {
		this.totalDiscounts = totalDiscounts;
	}
	public double getTotalSales() {
		return totalSales;
	}
	public void setTotalSales(double totalSales) {
		this.totalSales = totalSales;
	}
	public int getTotalOrdersRecorded() {
		return totalOrdersRecorded;
	}
	public void setTotalOrdersRecorded(int totalOrdersRecorded) {
		this.totalOrdersRecorded = totalOrdersRecorded;
	}
	public double getTotalTaxes() {
		return totalTaxes;
	}
	public void setTotalTaxes(double totalTaxes) {
		this.totalTaxes = totalTaxes;
	}
	public double getTotalNetSales() {
		return totalNetSales;
	}
	public void setTotalNetSales(double totalNetSales) {
		this.totalNetSales = totalNetSales;
	}
	
	
	public int getTotalQuantity() {
		return totalQuantity;
	}
	public void setTotalQuantity(int totalQuantity) {
		this.totalQuantity = totalQuantity;
	}
	public double getGst() {
		return gst;
	}
	public void setGst(double gst) {
		this.gst = gst;
	}
	public double getSubTotalPrice() {
		return SubTotalPrice;
	}
	public void setSubTotalPrice(double subTotalPrice) {
		SubTotalPrice = subTotalPrice;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getStaffName() {
		return staffName;
	}
	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}
	public int getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(int orderNo) {
		this.orderNo = orderNo;
	}
	public int getTotalItems() {
		return totalItems;
	}
	public void setTotalItems(int totalItems) {
		this.totalItems = totalItems;
	}
	public double getTotalSavings() {
		return totalSavings;
	}
	public void setTotalSavings(double totalSavings) {
		this.totalSavings = totalSavings;
	}
	public double getTotalOrderPrice() {
		return totalOrderPrice;
	}
	public void setTotalOrderPrice(double totalOrderPrice) {
		this.totalOrderPrice = totalOrderPrice;
	}

}
