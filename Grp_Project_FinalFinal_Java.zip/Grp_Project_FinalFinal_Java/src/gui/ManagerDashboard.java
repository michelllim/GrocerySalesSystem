package gui;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

import controller.MainFrame;
import data.Item;
import data.OrderDetail;
import data.User;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Dimension;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import java.awt.Component;
import java.awt.Container;

import javax.swing.JTabbedPane;

public class ManagerDashboard extends JPanel{
	private MainFrame main;
	private User user;
	private int index;
	private OrderDetail[] od;
	private Map<Integer, List<Double>> sales;
	private JLabel tnet;
	private JLabel tsales;
	private JLabel tor;
	private JPanel panel_2;
	private JPanel panel_8;
 	private DefaultTableModel model;
	private JTable table;
	
	public ManagerDashboard(MainFrame main, User user) {
		this.main = main;
		this.user = user;
		setLayout(null);
		this.setSize(1120, 665);
		
//		main.getController().setDefaultOrders();
//		main.getController().setDefaultItem();
		
		setBackground(new Color(255, 240, 245));
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(221, 160, 221));
		panel.setBounds(0, 0, 1120, 94);
		add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMDashboard(user);
			}
		});
		lblNewLabel.setBounds(24, 18, 69, 62);
		Image img = new ImageIcon(this.getClass().getResource("/loginiconn.png")).getImage().getScaledInstance(lblNewLabel.getWidth(), lblNewLabel.getHeight(), Image.SCALE_SMOOTH);
		lblNewLabel.setIcon(new ImageIcon(img));	
		panel.add(lblNewLabel);
		
		JLabel lblGrocerySalesSystem = new JLabel("Joy Minimart");
		lblGrocerySalesSystem.setForeground(new Color(139, 0, 139));
		lblGrocerySalesSystem.setFont(new Font("Segoe UI Semilight", Font.BOLD, 50));
		lblGrocerySalesSystem.setBounds(386, 13, 355, 67);
		panel.add(lblGrocerySalesSystem);
		
		JLabel label = new JLabel("");
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showLogin();
			}
			
		});
		label.setBounds(1054, 29, 54, 42);
		Image img1 = new ImageIcon(this.getClass().getResource("/logout.png")).getImage().getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_SMOOTH);
		label.setIcon(new ImageIcon(img1));
		panel.add(label);
		
		JLabel label_2 = new JLabel(user.getStaffName());
		label_2.setBounds(922, 29, 104, 42);
		panel.add(label_2);
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		JLabel lblWelcome = new JLabel("Welcome,");
		lblWelcome.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblWelcome.setBounds(833, 38, 77, 26);
		panel.add(lblWelcome);
		
		JPanel panel_1 = new JPanel();
		panel_1.setForeground(new Color(255, 204, 255));
		panel_1.setBackground(new Color(224, 255, 255));
		panel_1.setBounds(0, 121, 1120, 50);
		add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblItemDetails = new JLabel("Home");
		lblItemDetails.setForeground(new Color(0, 0, 0));
		lblItemDetails.setBounds(493, 0, 104, 50);
		panel_1.add(lblItemDetails);
		lblItemDetails.setFont(new Font("Tahoma", Font.BOLD, 25));
		
		JLabel lblCreateItems = new JLabel("Create Items");
		lblCreateItems.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMCreateScreen(user);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblCreateItems.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblCreateItems.setForeground(new Color(0, 0, 0));
			}
			
		});
		lblCreateItems.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblCreateItems.setBounds(86, 92, 116, 26);
		add(lblCreateItems);
		
		JLabel lblViewItems = new JLabel("View Items");
		lblViewItems.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMViewItems(user);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblViewItems.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblViewItems.setForeground(new Color(0, 0, 0));
			}
		});
		
		JLabel lblHome = new JLabel("Home");
		lblHome.setForeground(new Color(0, 0, 0));
		
				lblHome.setBackground(new Color(240, 255, 255));
				lblHome.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent arg0) {
						main.showMDashboard(user);
					}
					@Override
					public void mouseEntered(MouseEvent e) {
						lblHome.setForeground(new Color(245, 255, 250));
					}
					@Override
					public void mouseExited(MouseEvent e) {
						lblHome.setForeground(new Color(0, 0, 0));
					}
				});
				lblHome.setFont(new Font("Tahoma", Font.PLAIN, 20));
				lblHome.setBounds(10, 92, 56, 26);
				add(lblHome);
		lblViewItems.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblViewItems.setBounds(229, 92, 109, 26);
		add(lblViewItems);
		
		JLabel lblViewSaleSummary = new JLabel("View Sale Summary");
		lblViewSaleSummary.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMSaleSummary(user);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblViewSaleSummary.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblViewSaleSummary.setForeground(new Color(0, 0, 0));
			}
		});
		lblViewSaleSummary.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblViewSaleSummary.setBounds(360, 92, 195, 26);
		add(lblViewSaleSummary);
		
		JLabel lblTrackInventory = new JLabel("Track Inventory");
		lblTrackInventory.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMInventory(user);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblTrackInventory.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblTrackInventory.setForeground(new Color(0, 0, 0));
			}
		});
		lblTrackInventory.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTrackInventory.setBounds(567, 92, 140, 26);
		add(lblTrackInventory);
		
		JLabel lblViewOrders = new JLabel("View Orders");
		lblViewOrders.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMViewOrders(user);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblViewOrders.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblViewOrders.setForeground(new Color(0, 0, 0));
			}
		});
		lblViewOrders.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblViewOrders.setBounds(733, 92, 116, 26);
		add(lblViewOrders);
		
		JLabel lblDiscountItems = new JLabel("Discount");
		lblDiscountItems.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showMDiscount(user);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblDiscountItems.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblDiscountItems.setForeground(new Color(0, 0, 0));
			}
		});
		lblDiscountItems.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblDiscountItems.setBounds(871, 92, 109, 26);
		add(lblDiscountItems);
		
		JLabel lblChangeRole = new JLabel("Change Role");
		lblChangeRole.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				main.showStaffMenuScreen(user);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblChangeRole.setForeground(new Color(245, 255, 250));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblChangeRole.setForeground(new Color(0, 0, 0));
			}
		});
		lblChangeRole.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblChangeRole.setBounds(979, 92, 129, 26);
		add(lblChangeRole);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBounds(0, 93, 1120, 35);
		add(panel_4);
		panel_4.setBackground(new Color(255, 204, 255));
		
		this.panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 255, 255));
		panel_2.setBounds(557, 184, 522, 291);
		add(panel_2);
		
		this.tor = new JLabel("0");
		tor.setForeground(new Color(199, 21, 133));
		tor.setFont(new Font("Tahoma", Font.PLAIN, 30));
		tor.setBounds(51, 257, 140, 84);
		add(tor);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBackground(new Color(248, 248, 255));
		panel_5.setBounds(43, 230, 148, 111);
		add(panel_5);
		
		JLabel label_6 = new JLabel("All Orders");
		label_6.setFont(new Font("Tahoma", Font.BOLD, 15));
		label_6.setBackground(Color.WHITE);
		panel_5.add(label_6);
		
		this.tsales = new JLabel("$0");
		tsales.setForeground(new Color(199, 21, 133));
		tsales.setFont(new Font("Tahoma", Font.PLAIN, 30));
		tsales.setAlignmentX(0.5f);
		tsales.setBounds(51, 391, 141, 84);
		add(tsales);
		
		JPanel panel_6 = new JPanel();
		panel_6.setBackground(new Color(248, 248, 255));
		panel_6.setBounds(43, 364, 149, 111);
		add(panel_6);
		
		JLabel label_8 = new JLabel("Total Sales");
		label_8.setFont(new Font("Tahoma", Font.BOLD, 15));
		label_8.setBackground(Color.WHITE);
		panel_6.add(label_8);
		
		this.tnet = new JLabel("$0");
		tnet.setForeground(new Color(199, 21, 133));
		tnet.setFont(new Font("Tahoma", Font.PLAIN, 30));
		tnet.setBounds(51, 526, 141, 84);
		add(tnet);
		
		JPanel panel_7 = new JPanel();
		panel_7.setForeground(new Color(199, 21, 133));
		panel_7.setBackground(new Color(248, 248, 255));
		panel_7.setBounds(43, 499, 149, 111);
		add(panel_7);
		
		JLabel label_10 = new JLabel("Net Sales");
		label_10.setFont(new Font("Tahoma", Font.BOLD, 15));
		label_10.setBackground(Color.WHITE);
		panel_7.add(label_10);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(255, 255, 255));
		panel_3.setBounds(43, 184, 148, 33);
		add(panel_3);
		
		JLabel lblTotalSales = new JLabel("Total Sales");
		lblTotalSales.setBackground(new Color(255, 255, 255));
		panel_3.add(lblTotalSales);
		lblTotalSales.setFont(new Font("Tahoma", Font.BOLD, 20));
		
		JScrollPane scrollPane = new JScrollPane((Component) null);
		scrollPane.setBounds(229, 488, 850, 158);
		add(scrollPane);

		table = new JTable(model);
		Object[] columns = {
				"Staff Name","Order No.","Date","Time","Total Amount"
			};
		this.model = new DefaultTableModel(0,5);
		this.model.setColumnIdentifiers(columns);
		scrollPane.setViewportView(table);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(229, 184, 297, 291);
		add(tabbedPane);
		
		this.panel_8 = new JPanel();
		panel_8.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("Inventory", null, panel_8, null);
		
		this.panel_9 = new JPanel();
		panel_9.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("Item Sold", null, panel_9, null);
		
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				main.showMViewOrders(user);
			}
		});
		
		setSaleLabels();
    	populateSalesMonth();
    	populateTable();
    	populatePieChartItemsStock();
        populatePieChartStockSold();

    	
	}
	
	private DecimalFormat decfor1 = new DecimalFormat("0");//0dp format
	private DecimalFormat decfor = new DecimalFormat("0.00");//2dp format
	private Map<String, List<Double>> sales2;
	private Item[] items;
	private OrderDetail[] OrderDetail;
	private data.OrderDetail[] orders;
	private Container panel_9;

	
	public void setSaleLabels(){
		try{
			this.sales = this.main.getController().calcSalesByYear();
		    List<Double> objectList = sales.get(LocalDate.now().getYear());
		    this.tor.setText(""+decfor1.format(objectList.get(5)));
		    this.tnet.setText("$"+decfor.format(objectList.get(1)));
		    this.tsales.setText("$" +decfor.format(objectList.get(0)));
		    }
		catch(NullPointerException e){
			JOptionPane.showMessageDialog(null, "Please import data in View Orders and View Items");
		}
	}
	
	public void populateSalesMonth(){
		// Remove the current chart from panel_9
		panel_2.removeAll();
		panel_2.revalidate();
		panel_2.repaint();

		this.sales2 = this.main.getController().calcSalesByMonth();

	    // Create a dataset for the sales graph
	    DefaultCategoryDataset dataset = new DefaultCategoryDataset();

	    // Populate the dataset with sales data from orderDList
	    for (String month: sales2.keySet()) {
	    	List<Double> objectList = sales2.get(month);
	        dataset.addValue(objectList.get(5), "Orders", month);
	    }

	    // Create the bar chart
	    JFreeChart chart = ChartFactory.createBarChart(
	            "Peak Month of Orders",
	            "Month",
	            "Orders Recorded",
	            dataset,
	            PlotOrientation.VERTICAL,
	            true,
	            true,
	            false
	    );
	    
	    // Customize the bar colors
	    CategoryPlot plot = chart.getCategoryPlot();
	    BarRenderer renderer = new BarRenderer();
	    plot.setRenderer(renderer);
	    
	    // Set the color for each series (in this case, only one series)
	    renderer.setSeriesPaint(0, Color.BLUE); // Change to the desired color

	    plot.setBackgroundPaint(new Color(240, 240, 240)); // Light gray color
	    // Set the grid line color of the plot
	    plot.setRangeGridlinePaint(Color.GRAY); // Change Color.GRAY to desired color

	    ChartPanel chartPanel = new ChartPanel(chart);
	    chartPanel.setBackground(Color.WHITE);
	    chartPanel.setForeground(Color.WHITE);
	    chartPanel.setBounds(12, 5, 1008, 304);
	    
		chartPanel.setPreferredSize(new Dimension(522, 280)); // Set preferred size
	    this.panel_2.add(chartPanel);
	    
	    // Refresh the panel to show the new chart
	    panel_2.validate();
	    panel_2.repaint();
	}
	
	public void populatePieChartStockSold() {
	    // Remove the current chart from panel_9
	    panel_9.removeAll();
	    panel_9.revalidate();
	    panel_9.repaint();
	    
	    // Create dataset
	    DefaultPieDataset dataset3 = new DefaultPieDataset();
	    this.items = this.main.getController().getAllItems();
	    
	    int totalStockSold = 0;
	    
	    for(int i=0; i<items.length; i++){
			Item op = items[i];
	        totalStockSold += op.getItemStockSold();
	    }

	    for (int i=0; i<items.length; i++) {
	    	Item op = items[i];
	        double percentage2 = (double) op.getItemStockSold() / totalStockSold * 100;
	        dataset3.setValue(op.getItemName() + " (" + String.format("%.2f", percentage2) + "%)", percentage2);
	    }

	    // Create pie chart
	    JFreeChart chart3 = ChartFactory.createPieChart(
	            "Popular Items",
	            dataset3,
	            true,
	            true,
	            false
	    );
	    // Customize plot
	    PiePlot plot3 = (PiePlot) chart3.getPlot();
	    plot3.setSectionOutlinesVisible(false);

	    ChartPanel chartPanel3 = new ChartPanel(chart3);
	    chartPanel3.setPreferredSize(new Dimension(295, 260));
	    this.panel_9.add(chartPanel3);

		// Refresh the panel to show the new chart
		panel_9.validate();
	    panel_9.repaint();

	}
	
	public void populatePieChartItemsStock() {
	    // Remove the current chart from panel_8
	    panel_8.removeAll();
	    panel_8.revalidate();
	    panel_8.repaint();
	    
	    // Create dataset
	    DefaultPieDataset dataset2 = new DefaultPieDataset();
	    this.items = this.main.getController().getAllItems();
	    
	    int totalStock = 0;
	    
	    for(int i=0; i<items.length; i++){
			Item op = items[i];
	        totalStock += op.getItemStock();
	    }

	    for (int i=0; i<items.length; i++) {
	    	Item op = items[i];
	        double percentage = (double) op.getItemStock() / totalStock * 100;
	        dataset2.setValue(op.getItemName() + " (" + String.format("%.2f", percentage) + "%)", percentage);
	        System.out.println(percentage);
	    }

	    // Create pie chart
	    JFreeChart chart2 = ChartFactory.createPieChart(
	            "Items in Inventory",
	            dataset2,
	            true,
	            true,
	            false
	    );
	    // Customize plot
	    PiePlot plot2 = (PiePlot) chart2.getPlot();
	    plot2.setSectionOutlinesVisible(false);

	    ChartPanel chartPanel2 = new ChartPanel(chart2);
	    chartPanel2.setPreferredSize(new Dimension(295, 260));
	    this.panel_8.add(chartPanel2);
	    
	    // Refresh the panel to show the new chart
	    panel_8.validate();
	    panel_8.repaint();
	}
	
	private void populateTable(){
		OrderDetail = main.getController().getAllOrderDetails();
		Object[] row = new Object[5];
		DecimalFormat decfor = new DecimalFormat("0.00");
		for(int i = 0; i < OrderDetail.length; i++){
			OrderDetail op = OrderDetail[i];
			row[0] = op.getStaffName();
			row[1] = op.getOrderNo();
			row[2] = op.getDate();
			row[3] = op.getTime();
			row[4] = decfor.format(op.getTotalOrderPrice());
			
			System.out.println("row[0]"+row[0]);
			System.out.println(row[1]);
			System.out.println(row[2]);
			System.out.println(row[3]);
			
			model.addRow(row);
			
		}
		this.table.setModel(model);
	}
}