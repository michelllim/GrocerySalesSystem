package controller;

import java.awt.CardLayout;

import javax.swing.JFrame;

import data.Item;
import data.User;
import gui.Login;
import gui.ManagerCreateScreen;
import gui.ManagerDashboard;
import gui.ManagerDiscountScreen;
import gui.ManagerEditScreen;
import gui.ManagerOrderDetailsScreen;
import gui.ManagerViewOrders;
import gui.ManagerSaleSummaryScreen;
import gui.ManagerTrackInventory;
import gui.ManagerViewItems;
import gui.RegUserScreen;
import gui.StaffCreateOrderItemScreen;
import gui.StaffMenuScreen;
import gui.StaffReceiptScreen;

public class MainFrame extends JFrame {

	public RegUserScreen reguserScreen;
	public Controller controller;

	private CardLayout card;
	private Controller cont;

	public MainFrame()

	{
		this.setTitle("User Registration");
		this.setSize(1135, 710);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.card = new CardLayout();
		this.setLayout(this.card);
		this.cont = new Controller();
		this.showRegScreen();
		//this.showLogin();
		this.setVisible(true);
	}


	public void showRegScreen() {
		RegUserScreen p1 = new RegUserScreen(this);
		this.add(p1, "Panel1");
		this.card.show(this.getContentPane(), "Panel1");
	}

	public void showLogin() {
		Login p2 = new Login(this);
		this.add(p2, "Panel2");
		this.card.show(this.getContentPane(), "Panel2");
	}
	
	public void showCreateOrderScreen(int index, User sname) {  //hold
		StaffCreateOrderItemScreen p3 = new StaffCreateOrderItemScreen(this, index, sname);
		this.add(p3, "Staff");
		this.card.show(this.getContentPane(), "Staff");
	}
	
	public void showStaffMenuScreen(User user){
		StaffMenuScreen p4 = new StaffMenuScreen(this,user);
		this.add(p4, "StaffMenu");
		this.card.show(this.getContentPane(), "StaffMenu");
		
	}
    public void showMDashboard(User user){
		ManagerDashboard p5 = new ManagerDashboard(this,user);
		this.add(p5, "Dashboard");
		this.card.show(this.getContentPane(), "Dashboard");
	}
	 
	 public void showMSaleSummary(User user){
		 ManagerSaleSummaryScreen p6 = new ManagerSaleSummaryScreen(this, user);
		 this.add(p6, "SalesSummary");
		 this.card.show(this.getContentPane(), "SalesSummary");
	 }


	public static void main(String[] args) {
		MainFrame gui = new MainFrame();
		gui.setLocationRelativeTo(null);
		
	}


	public RegUserScreen getReguserscren() {
		return reguserScreen;
	}

	public void setReguserscren(RegUserScreen reguserscren) {
		this.reguserScreen = reguserscren;
	}

	public Controller getController() {

		return this.cont;
	}

	public void setController(Controller controller) {
		this.controller = controller;
	}

	public void showMViewItems(User user) {
		ManagerViewItems p7 = new ManagerViewItems(this,user);
		this.add(p7, "ViewItems");
		this.card.show(this.getContentPane(), "ViewItems");
	}
		
	public void showMCreateScreen(User user) {
		ManagerCreateScreen p8 = new ManagerCreateScreen(this,user);
		this.add(p8, "CreateScreen");
		this.card.show(this.getContentPane(), "CreateScreen");
	}
	
	public void showMEditScreen(int index, Item item, User user) {
		ManagerEditScreen p9 = new ManagerEditScreen(this, index, item, user);
		this.add(p9, "EditScreen");
		this.card.show(this.getContentPane(), "EditScreen");
		
	}
	
	public void showMDiscount(User user) {
		ManagerDiscountScreen p10 = new ManagerDiscountScreen(this, user);
		this.add(p10, "DiscountScreen");
		this.card.show(this.getContentPane(), "DiscountScreen");
		
	}
	
	public void showMOrderDetails(User user1, int i) {
		ManagerOrderDetailsScreen p11 = new ManagerOrderDetailsScreen(this,user1, i);
		this.add(p11, "OrderDetails");
		this.card.show(this.getContentPane(), "OrderDetails");
		
	}
	
	public void showMViewOrders(User user1) {
		ManagerViewOrders p12 = new ManagerViewOrders(this,user1);
		this.add(p12, "ViewOrders");
		this.card.show(this.getContentPane(), "ViewOrders");
		
	}
	
	
	public void showMInventory(User user) {
		ManagerTrackInventory p14 = new ManagerTrackInventory(this, user);
		this.add(p14, "Inventory");
		this.card.show(this.getContentPane(), "Inventory");
		
	}
	
	public void showReceipt(int index, User user){
		StaffReceiptScreen p15 = new StaffReceiptScreen(this,index, user);
		this.add(p15, "Receipt");
		this.card.show(this.getContentPane(), "Receipt");
	}

	
}